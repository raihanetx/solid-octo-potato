import { db } from '@/db'
import { settings } from '@/db/schema'
import { eq } from 'drizzle-orm'
import { cookies } from 'next/headers'
import { SignJWT, jwtVerify } from 'jose'
import bcrypt from 'bcryptjs'
import { 
  auditLog, 
  checkRateLimitDB, 
  recordFailedAttemptDB, 
  clearFailedAttemptsDB 
} from './security'

// Session configuration
const SESSION_SECRET = process.env.SESSION_SECRET || 'ecomart-session-secret-2024'
const secretKey = new TextEncoder().encode(SESSION_SECRET)
const SESSION_COOKIE = 'admin_session'
const SESSION_DURATION = 4 * 60 * 60 // 4 hours (reduced from 24)

// ============================================
// PASSWORD HASHING
// ============================================

export async function hashPassword(password: string): Promise<string> {
  const salt = await bcrypt.genSalt(12)
  return bcrypt.hash(password, salt)
}

export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  if (hashedPassword.startsWith('$2')) {
    return bcrypt.compare(password, hashedPassword)
  }
  // Legacy support: plain text (migrate on next login)
  return password === hashedPassword
}

export function isHashed(password: string): boolean {
  return password.startsWith('$2a$') || password.startsWith('$2b$') || password.startsWith('$2y$')
}

// ============================================
// SESSION MANAGEMENT
// ============================================

export async function createSession(username: string): Promise<string> {
  const token = await new SignJWT({ 
    username, 
    role: 'admin',
    iat: Math.floor(Date.now() / 1000)
  })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('4h') // 4 hours
    .sign(secretKey)
  
  return token
}

export async function verifySession(token: string): Promise<{ username: string; role: string } | null> {
  try {
    const { payload } = await jwtVerify(token, secretKey)
    return payload as { username: string; role: string }
  } catch {
    return null
  }
}

export async function refreshSession(token: string): Promise<string | null> {
  const session = await verifySession(token)
  if (!session) return null
  return createSession(session.username)
}

// ============================================
// AUTHENTICATION
// ============================================

async function getAdminCredentials() {
  try {
    const result = await db.select().from(settings).where(eq(settings.id, 1)).limit(1)
    if (result.length > 0 && result[0].adminPassword) {
      return {
        username: result[0].adminUsername || 'admin',
        password: result[0].adminPassword,
      }
    }
  } catch (error) {
    console.error('Error fetching admin credentials:', error)
  }
  return { username: 'admin', password: 'admin123' }
}

export async function authenticateAdmin(
  username: string, 
  password: string, 
  ip: string = 'unknown',
  userAgent: string = 'unknown'
): Promise<{ 
  success: boolean
  token?: string
  error?: string
  remainingAttempts?: number 
  lockedMinutes?: number
}> {
  // Check rate limit (persistent, database-backed)
  const rateCheck = await checkRateLimitDB(ip)
  
  if (!rateCheck.allowed) {
    await auditLog({
      action: 'rate_limited',
      category: 'auth',
      ipAddress: ip,
      userAgent,
      details: `Login blocked for ${rateCheck.lockedMinutes} minutes`
    })
    
    return { 
      success: false, 
      error: `Too many failed attempts. Try again in ${rateCheck.lockedMinutes} minutes.`,
      remainingAttempts: 0,
      lockedMinutes: rateCheck.lockedMinutes
    }
  }
  
  const creds = await getAdminCredentials()
  
  // Check username
  if (username !== creds.username) {
    const attempt = await recordFailedAttemptDB(ip)
    await auditLog({
      action: 'login_failed',
      category: 'auth',
      ipAddress: ip,
      userAgent,
      details: `Invalid username: ${username}`
    })
    
    return { 
      success: false, 
      error: 'Invalid credentials',
      remainingAttempts: attempt.count >= 5 ? 0 : 5 - attempt.count
    }
  }
  
  // Verify password
  const isValid = await verifyPassword(password, creds.password)
  
  if (!isValid) {
    const attempt = await recordFailedAttemptDB(ip)
    await auditLog({
      action: 'login_failed',
      category: 'auth',
      ipAddress: ip,
      userAgent,
      details: 'Invalid password'
    })
    
    return { 
      success: false, 
      error: 'Invalid credentials',
      remainingAttempts: attempt.count >= 5 ? 0 : 5 - attempt.count
    }
  }
  
  // SUCCESS
  await clearFailedAttemptsDB(ip)
  await auditLog({
    action: 'login_success',
    category: 'auth',
    ipAddress: ip,
    userAgent,
    details: `User: ${username}`
  })
  
  // Auto-migrate plain text to hash
  if (!isHashed(creds.password)) {
    try {
      const hashedPassword = await hashPassword(password)
      await db.update(settings)
        .set({ adminPassword: hashedPassword })
        .where(eq(settings.id, 1))
      console.log('✅ Password auto-migrated to secure hash')
    } catch (error) {
      console.error('Failed to migrate password hash:', error)
    }
  }
  
  const token = await createSession(username)
  return { success: true, token }
}

// Get current session
export async function getSession() {
  const cookieStore = await cookies()
  const token = cookieStore.get(SESSION_COOKIE)?.value
  if (!token) return null
  return verifySession(token)
}

// Check if authenticated
export async function isAuthenticated(): Promise<boolean> {
  const session = await getSession()
  return session !== null
}

// Logout
export async function logout(ip: string = 'unknown'): Promise<void> {
  const session = await getSession()
  if (session) {
    await auditLog({
      action: 'logout',
      category: 'auth',
      ipAddress: ip,
      details: `User: ${session.username}`
    })
  }
}

export const SESSION_COOKIE_NAME = SESSION_COOKIE
export const SESSION_DURATION_SECONDS = SESSION_DURATION
