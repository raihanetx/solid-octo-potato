import { NextRequest, NextResponse } from 'next/server'
import { v2 as cloudinary } from 'cloudinary'
import { db } from '@/db'
import { settings } from '@/db/schema'
import { eq } from 'drizzle-orm'

// Get Cloudinary config from DATABASE ONLY
async function getCloudinaryConfig(): Promise<{
  cloud_name: string
  api_key: string
  api_secret: string
} | null> {
  try {
    const result = await db.select().from(settings).where(eq(settings.id, 1)).limit(1)
    
    if (result.length > 0) {
      const s = result[0]
      
      if (s.cloudinaryCloudName && s.cloudinaryApiKey && s.cloudinaryApiSecret) {
        return {
          cloud_name: s.cloudinaryCloudName,
          api_key: s.cloudinaryApiKey,
          api_secret: s.cloudinaryApiSecret,
        }
      }
    }
  } catch (error) {
    console.error('Failed to fetch Cloudinary config from database:', error)
  }
  
  return null
}

// POST - Upload image to Cloudinary
export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get('file') as File
    const type = formData.get('type') as string // 'logo', 'favicon', 'hero', 'product', 'category'

    if (!file) {
      return NextResponse.json({ error: 'No file uploaded' }, { status: 400 })
    }

    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/x-icon', 'image/vnd.microsoft.icon']
    if (!allowedTypes.includes(file.type)) {
      return NextResponse.json({ error: 'Invalid file type. Only images are allowed.' }, { status: 400 })
    }

    // Validate file size (max 10MB for Cloudinary)
    const maxSize = 10 * 1024 * 1024
    if (file.size > maxSize) {
      return NextResponse.json({ error: 'File too large. Maximum size is 10MB.' }, { status: 400 })
    }

    // Get Cloudinary config from DATABASE ONLY
    const config = await getCloudinaryConfig()
    
    if (!config) {
      return NextResponse.json({ 
        error: 'Cloudinary is not configured. Please add Cloudinary credentials in Admin > Credentials > Cloudinary.',
        needsConfig: true
      }, { status: 400 })
    }
    
    // Configure Cloudinary
    cloudinary.config({
      cloud_name: config.cloud_name,
      api_key: config.api_key,
      api_secret: config.api_secret,
    })

    // Convert file to base64 for upload
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)
    const base64 = buffer.toString('base64')
    const dataUri = `data:${file.type};base64,${base64}`

    // Determine folder based on type
    const folder = `ecomart/${type || 'images'}`

    // Upload to Cloudinary
    const uploadResult = await cloudinary.uploader.upload(dataUri, {
      folder,
      resource_type: 'image',
      transformation: [
        { quality: 'auto:good' },
        { fetch_format: 'auto' },
      ],
    })

    return NextResponse.json({
      success: true,
      url: uploadResult.secure_url,
      publicId: uploadResult.public_id,
      fileName: uploadResult.public_id.split('/').pop(),
      width: uploadResult.width,
      height: uploadResult.height,
    })
  } catch (error) {
    console.error('Error uploading image to Cloudinary:', error)
    return NextResponse.json({ error: 'Failed to upload image' }, { status: 500 })
  }
}

// DELETE - Delete image from Cloudinary
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const publicId = searchParams.get('publicId')

    if (!publicId) {
      return NextResponse.json({ error: 'Public ID required' }, { status: 400 })
    }

    // Get Cloudinary config from DATABASE ONLY
    const config = await getCloudinaryConfig()
    
    if (!config) {
      return NextResponse.json({ error: 'Cloudinary not configured' }, { status: 400 })
    }
    
    cloudinary.config({
      cloud_name: config.cloud_name,
      api_key: config.api_key,
      api_secret: config.api_secret,
    })

    // Delete from Cloudinary
    const result = await cloudinary.uploader.destroy(publicId)

    if (result.result === 'ok') {
      return NextResponse.json({ success: true, message: 'Image deleted' })
    } else {
      return NextResponse.json({ error: 'Failed to delete image', result }, { status: 400 })
    }
  } catch (error) {
    console.error('Error deleting image from Cloudinary:', error)
    return NextResponse.json({ error: 'Failed to delete image' }, { status: 500 })
  }
}
