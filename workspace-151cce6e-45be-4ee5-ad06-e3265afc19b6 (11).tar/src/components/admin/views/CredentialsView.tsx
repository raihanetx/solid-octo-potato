'use client'

import React, { useState, useMemo } from 'react'
import { useAdmin } from '@/components/admin/context/AdminContext'

interface Credential {
  id: number
  type: 'admin' | 'courier' | 'cloudinary'
  label: string
  value: string
  isEditing: boolean
  icon: string
  timestampKey: string // Key to look up timestamp in settings
  fieldKey: string // Key to save to API
  required?: boolean
}

// Helper function to format last edited time
const formatLastEdited = (isoString: string | null | undefined): string => {
  if (!isoString) return 'Never edited'
  
  try {
    const date = new Date(isoString)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24))
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60))
    const diffMinutes = Math.floor(diffMs / (1000 * 60))
    
    let timeAgo = ''
    if (diffDays > 0) {
      timeAgo = `${diffDays} day${diffDays > 1 ? 's' : ''} ago`
    } else if (diffHours > 0) {
      timeAgo = `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`
    } else if (diffMinutes > 0) {
      timeAgo = `${diffMinutes} minute${diffMinutes > 1 ? 's' : ''} ago`
    } else {
      timeAgo = 'Just now'
    }
    
    const dateStr = date.toLocaleDateString('en-US', { 
      day: 'numeric', 
      month: 'long', 
      year: 'numeric' 
    })
    const timeStr = date.toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit', 
      hour12: true 
    }).toLowerCase()
    
    return `${timeAgo} - ${dateStr} - ${timeStr}`
  } catch {
    return 'Never edited'
  }
}

const CredentialsView: React.FC = () => {
  const { settings, showToastMsg, refetchSettings } = useAdmin()
  const [activeTab, setActiveTab] = useState<'admin' | 'courier' | 'cloudinary'>('admin')
  const [saving, setSaving] = useState(false)
  const [editingId, setEditingId] = useState<number | null>(null)

  // Define all credentials with their timestamp keys
  const credentialDefs: Credential[] = useMemo(() => [
    // Admin credentials - each has own timestamp
    { 
      id: 1, 
      type: 'admin', 
      label: 'Admin Username', 
      value: settings.adminUsername || 'admin', 
      isEditing: false, 
      icon: 'fa-user', 
      timestampKey: 'adminUsernameUpdatedAt',
      fieldKey: 'adminUsername',
      required: true 
    },
    { 
      id: 2, 
      type: 'admin', 
      label: 'Admin Password', 
      value: settings.adminPassword || '', 
      isEditing: false, 
      icon: 'fa-lock', 
      timestampKey: 'adminPasswordUpdatedAt',
      fieldKey: 'adminPassword',
      required: true 
    },
    // Courier credentials - all share steadfastApiUpdatedAt
    { 
      id: 3, 
      type: 'courier', 
      label: 'Steadfast API Key', 
      value: settings.steadfastApiKey || '', 
      isEditing: false, 
      icon: 'fa-key', 
      timestampKey: 'steadfastApiUpdatedAt',
      fieldKey: 'steadfastApiKey' 
    },
    { 
      id: 4, 
      type: 'courier', 
      label: 'Steadfast Secret Key', 
      value: settings.steadfastSecretKey || '', 
      isEditing: false, 
      icon: 'fa-shield-halved', 
      timestampKey: 'steadfastApiUpdatedAt',
      fieldKey: 'steadfastSecretKey' 
    },
    { 
      id: 5, 
      type: 'courier', 
      label: 'Steadfast Webhook URL', 
      value: settings.steadfastWebhookUrl || '', 
      isEditing: false, 
      icon: 'fa-link', 
      timestampKey: 'steadfastApiUpdatedAt',
      fieldKey: 'steadfastWebhookUrl' 
    },
    // Cloudinary credentials - all share cloudinaryUpdatedAt
    { 
      id: 6, 
      type: 'cloudinary', 
      label: 'Cloudinary Cloud Name', 
      value: settings.cloudinaryCloudName || '', 
      isEditing: false, 
      icon: 'fa-cloud', 
      timestampKey: 'cloudinaryUpdatedAt',
      fieldKey: 'cloudinaryCloudName' 
    },
    { 
      id: 7, 
      type: 'cloudinary', 
      label: 'Cloudinary API Key', 
      value: settings.cloudinaryApiKey || '', 
      isEditing: false, 
      icon: 'fa-key', 
      timestampKey: 'cloudinaryUpdatedAt',
      fieldKey: 'cloudinaryApiKey' 
    },
    { 
      id: 8, 
      type: 'cloudinary', 
      label: 'Cloudinary API Secret', 
      value: settings.cloudinaryApiSecret || '', 
      isEditing: false, 
      icon: 'fa-user-secret', 
      timestampKey: 'cloudinaryUpdatedAt',
      fieldKey: 'cloudinaryApiSecret' 
    },
  ], [settings])

  const [credentials, setCredentials] = useState<Credential[]>(credentialDefs)

  // Update credentials when settings change
  React.useEffect(() => {
    setCredentials(credentialDefs.map(c => ({ ...c, isEditing: editingId === c.id })))
  }, [credentialDefs, editingId])

  const toggleEdit = (id: number) => {
    const cred = credentials.find(c => c.id === id)
    
    if (cred?.isEditing) {
      // Save on toggle off
      saveCredential(id)
    } else {
      setEditingId(id)
      setCredentials(prev => prev.map(c => 
        c.id === id ? { ...c, isEditing: true } : c
      ))
    }
  }

  const updateValue = (id: number, newValue: string) => {
    setCredentials(prev => prev.map(c => 
      c.id === id ? { ...c, value: newValue } : c
    ))
  }

  const saveCredential = async (id: number) => {
    const cred = credentials.find(c => c.id === id)
    if (!cred) return

    // Validation
    if (cred.required && !cred.value.trim()) {
      showToastMsg(`${cred.label} cannot be empty`)
      return
    }

    setSaving(true)
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ [cred.fieldKey]: cred.value })
      })
      const data = await res.json()
      
      if (data.success) {
        await refetchSettings()
        setEditingId(null)
        setCredentials(prev => prev.map(c => 
          c.id === id ? { ...c, isEditing: false } : c
        ))
        showToastMsg(`${cred.label} updated successfully`)
      } else {
        showToastMsg(data.error || 'Failed to save')
      }
    } catch (error) {
      console.error('Save error:', error)
      showToastMsg('Error saving credential')
    }
    setSaving(false)
  }

  const handleKeyDown = (e: React.KeyboardEvent, id: number) => {
    if (e.key === 'Enter') {
      e.preventDefault()
      saveCredential(id)
    } else if (e.key === 'Escape') {
      setEditingId(null)
      setCredentials(prev => prev.map(c => ({ ...c, isEditing: false })))
    }
  }

  const filteredCredentials = credentials.filter(c => c.type === activeTab)

  return (
    <div className="p-12 bg-white min-h-screen" style={{ fontFamily: "'Inter', sans-serif" }}>
      <style jsx global>{`
        .rounded-5 { border-radius: 5px !important; }
        .table-container { border: 1px solid #cbd5e1; border-radius: 5px; overflow: hidden; }
        .credentials-table { width: 100%; border-collapse: collapse; }
        .credentials-table th, .credentials-table td { border: 1px solid #cbd5e1; }
        .credentials-table tr th:first-child, .credentials-table tr td:first-child { border-left: none; }
        .credentials-table tr th:last-child, .credentials-table tr td:last-child { border-right: none; }
        .credentials-table thead tr:first-child th { border-top: none; }
        .credentials-table tbody tr:last-child td { border-bottom: none; }
        .typing-input {
          background: transparent;
          border: none;
          outline: none;
          text-align: center;
          width: 100%;
          padding: 0;
          font-weight: 500;
          color: #0f172a;
        }
        .typing-input::placeholder {
          color: #94a3b8;
          font-style: italic;
        }
      `}</style>

      <div className="max-w-6xl mx-auto">
        {/* Security Status Banner */}
        <div className="mb-6 p-4 rounded-lg bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-green-500 flex items-center justify-center">
              <i className="fa-solid fa-shield-halved text-white text-lg"></i>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-semibold text-green-800">Security Active</h3>
                <span className="px-2 py-0.5 bg-green-500 text-white text-xs rounded-full font-medium">8/10</span>
              </div>
              <p className="text-sm text-green-600">
                Passwords encrypted with bcrypt • Login protected with rate limiting • Secure session cookies
              </p>
            </div>
          </div>
        </div>

        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Credentials</h1>
          <p className="text-sm text-slate-400">Secure access and API management</p>
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-3 mb-5 flex-wrap">
          <button 
            onClick={() => setActiveTab('admin')}
            className={`px-5 py-1.5 border rounded-5 text-sm font-semibold transition-all ${
              activeTab === 'admin' 
                ? 'border-slate-800 text-slate-900 bg-slate-50' 
                : 'border-slate-200 text-slate-400 hover:border-slate-300'
            }`}
          >
            Admin Credentials
          </button>
          <button 
            onClick={() => setActiveTab('courier')}
            className={`px-5 py-1.5 border rounded-5 text-sm font-semibold transition-all ${
              activeTab === 'courier' 
                ? 'border-slate-800 text-slate-900 bg-slate-50' 
                : 'border-slate-200 text-slate-400 hover:border-slate-300'
            }`}
          >
            Courier API
          </button>
          <button 
            onClick={() => setActiveTab('cloudinary')}
            className={`px-5 py-1.5 border rounded-5 text-sm font-semibold transition-all ${
              activeTab === 'cloudinary' 
                ? 'border-slate-800 text-slate-900 bg-slate-50' 
                : 'border-slate-200 text-slate-400 hover:border-slate-300'
            }`}
          >
            Cloudinary
          </button>
        </div>

        {/* Table */}
        <div className="table-container">
          <table className="credentials-table">
            <thead className="bg-slate-50">
              <tr className="text-[11px] uppercase tracking-widest text-slate-500">
                <th className="px-6 py-4 text-left font-bold">Credential Name</th>
                <th className="px-6 py-4 text-center font-bold">Current Value</th>
                <th className="px-6 py-4 text-center font-bold">Last Edited</th>
                <th className="px-6 py-4 text-center font-bold w-20">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredCredentials.map((cred) => {
                const timestamp = settings[cred.timestampKey as keyof typeof settings] as string | null
                const lastEdited = formatLastEdited(timestamp)
                
                return (
                  <tr key={cred.id} className="hover:bg-slate-50/30">
                    {/* Credential Name */}
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-4">
                        <div className="w-8 h-8 border border-slate-200 rounded-full flex items-center justify-center text-slate-400">
                          <i className={`fa-solid text-[10px] ${cred.icon}`}></i>
                        </div>
                        <div className="flex flex-col">
                          <span className="text-sm font-medium text-slate-700">{cred.label}</span>
                          {cred.required && (
                            <span className="text-[10px] text-red-400">Required</span>
                          )}
                        </div>
                      </div>
                    </td>

                    {/* Current Value */}
                    <td className="px-6 py-4 text-center">
                      {!cred.isEditing ? (
                        <span className="text-slate-300 tracking-[0.4em] font-mono text-xs select-none">
                          {cred.value ? '••••••••••••' : <span className="text-red-300 italic">Not set</span>}
                        </span>
                      ) : (
                        <input 
                          type="text" 
                          value={cred.value} 
                          onChange={(e) => updateValue(cred.id, e.target.value)}
                          onKeyDown={(e) => handleKeyDown(e, cred.id)}
                          className="typing-input text-sm"
                          autoFocus
                          disabled={saving}
                          placeholder={`Enter ${cred.label.toLowerCase()}`}
                        />
                      )}
                    </td>

                    {/* Last Edited */}
                    <td className="px-6 py-4 text-center">
                      <span className="text-xs text-slate-400 font-medium">{lastEdited}</span>
                    </td>

                    {/* Action */}
                    <td className="px-6 py-4 text-center">
                      <button 
                        onClick={() => toggleEdit(cred.id)} 
                        className={`transition-colors ${cred.isEditing ? 'text-green-600 hover:text-green-700' : 'text-slate-300 hover:text-slate-900'}`}
                        disabled={saving}
                      >
                        <i className={`${cred.isEditing ? 'fa-solid fa-check' : 'fa-regular fa-pen-to-square'}`}></i>
                      </button>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>

        {/* Status Info */}
        {saving && (
          <div className="mt-4 text-center text-sm text-slate-400">
            <i className="fa-solid fa-spinner fa-spin mr-2"></i>
            Saving...
          </div>
        )}
      </div>
    </div>
  )
}

export default CredentialsView
