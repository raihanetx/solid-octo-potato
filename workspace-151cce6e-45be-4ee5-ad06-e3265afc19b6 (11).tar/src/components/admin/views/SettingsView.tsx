'use client'

import React, { useState, useRef, useEffect } from 'react'
import { useAdmin } from '@/components/admin/context/AdminContext'

type SettingsTab = 'branding' | 'hero' | 'delivery' | 'social' | 'legal' | 'sections'

interface LegalPage {
  id: string
  name: string
  content: string
}

interface SectionItem {
  id: number
  label: string
  field: string
  value: string
  icon: string
  isEditing: boolean
  lastEdited: string
}

const SettingsView: React.FC = () => {
  const { settings, setSettings, showToastMsg, refetchSettings } = useAdmin()
  
  const [activeTab, setActiveTab] = useState<SettingsTab>('branding')
  const [previewModal, setPreviewModal] = useState(false)
  const [previewSrc, setPreviewSrc] = useState('')
  const [saving, setSaving] = useState(false)
  
  // Branding state
  const [brandingEditing, setBrandingEditing] = useState(false)
  const [websiteName, setWebsiteName] = useState('My Store')
  const [slogan, setSlogan] = useState('Premium Quality')
  const [logoUrl, setLogoUrl] = useState('')
  const [logoName, setLogoName] = useState('')
  const [faviconUrl, setFaviconUrl] = useState('')
  const [faviconName, setFaviconName] = useState('')
  
  // Hero state
  const [heroImages, setHeroImages] = useState<{name: string, url: string}[]>([])
  const [animationSpeed, setAnimationSpeed] = useState(3000)
  const [animationType, setAnimationType] = useState('Fade')
  const [heroEditing, setHeroEditing] = useState(false)
  
  // Delivery state
  const [deliveryEditing, setDeliveryEditing] = useState(false)
  const [insideDhaka, setInsideDhaka] = useState(60)
  const [outsideDhaka, setOutsideDhaka] = useState(120)
  const [universalCharge, setUniversalCharge] = useState(0)
  const [isUniversalOn, setIsUniversalOn] = useState(false)
  const [freeThreshold, setFreeThreshold] = useState(2000)
  
  // Social state
  const [socialEditing, setSocialEditing] = useState(false)
  const [phone, setPhone] = useState('')
  const [whatsapp, setWhatsapp] = useState('')
  const [facebook, setFacebook] = useState('')
  const [messenger, setMessenger] = useState('')
  
  // Legal state
  const [editingLegalId, setEditingLegalId] = useState<string | null>(null)
  const [legalPages, setLegalPages] = useState<LegalPage[]>([
    { id: 'about', name: 'About Us', content: '' },
    { id: 'terms', name: 'Terms and Conditions', content: '' },
    { id: 'refund', name: 'Refund Policy', content: '' },
    { id: 'privacy', name: 'Privacy Policy', content: '' }
  ])
  
  // Section Naming state
  const [sectionItems, setSectionItems] = useState<SectionItem[]>([
    { id: 1, label: 'First Section Name', field: 'firstSectionName', value: 'Categories', icon: 'fa-layer-group', isEditing: false, lastEdited: 'Never edited' },
    { id: 2, label: 'First Section Slogan', field: 'firstSectionSlogan', value: 'Browse by category', icon: 'fa-quote-left', isEditing: false, lastEdited: 'Never edited' },
    { id: 3, label: 'Second Section Name', field: 'secondSectionName', value: 'Offers', icon: 'fa-tag', isEditing: false, lastEdited: 'Never edited' },
    { id: 4, label: 'Second Section Slogan', field: 'secondSectionSlogan', value: 'Exclusive deals for you', icon: 'fa-quote-right', isEditing: false, lastEdited: 'Never edited' },
    { id: 5, label: 'Third Section Name', field: 'thirdSectionName', value: 'Featured', icon: 'fa-star', isEditing: false, lastEdited: 'Never edited' },
    { id: 6, label: 'Third Section Slogan', field: 'thirdSectionSlogan', value: 'Handpicked products', icon: 'fa-message', isEditing: false, lastEdited: 'Never edited' },
  ])
  
  const syncedRef = useRef(false)
  const logoInputRef = useRef<HTMLInputElement>(null)
  const faviconInputRef = useRef<HTMLInputElement>(null)
  const heroInputRef = useRef<HTMLInputElement>(null)

  // Sync settings from context - using queueMicrotask to avoid ESLint warning
  useEffect(() => {
    if (!syncedRef.current && settings) {
      queueMicrotask(() => {
        setWebsiteName(settings.websiteName || 'My Store')
        setSlogan(settings.slogan || 'Premium Quality')
        setLogoUrl(settings.logoUrl || '')
        setLogoName(settings.logoUrl ? 'logo' : '')
        setFaviconUrl(settings.faviconUrl || '')
        setFaviconName(settings.faviconUrl ? 'favicon' : '')
        
        // Parse hero images
        if (settings.heroImages) {
          try {
            const parsed = typeof settings.heroImages === 'string' 
              ? JSON.parse(settings.heroImages) 
              : settings.heroImages
            if (Array.isArray(parsed) && parsed.length > 0) {
              setHeroImages(parsed.map((url: string, i: number) => ({ name: `banner${i+1}`, url })))
            }
          } catch { /* empty */ }
        }
        
        // Hero animation settings
        setAnimationSpeed(settings.heroAnimationSpeed || 3000)
        setAnimationType(settings.heroAnimationType || 'Fade')
        
        setInsideDhaka(settings.insideDhakaDelivery || 60)
        setOutsideDhaka(settings.outsideDhakaDelivery || 120)
        setUniversalCharge(settings.universalDeliveryCharge || 0)
        setIsUniversalOn(settings.universalDelivery ?? false)
        setFreeThreshold(settings.freeDeliveryMin || 2000)
        
        setPhone(settings.phoneNumber || '')
        setWhatsapp(settings.whatsappNumber || '')
        setFacebook(settings.facebookUrl || '')
        setMessenger(settings.messengerUsername || '')
        
        // Set legal pages content
        setLegalPages([
          { id: 'about', name: 'About Us', content: settings.aboutUs || '' },
          { id: 'terms', name: 'Terms and Conditions', content: settings.termsConditions || '' },
          { id: 'refund', name: 'Refund Policy', content: settings.refundPolicy || '' },
          { id: 'privacy', name: 'Privacy Policy', content: settings.privacyPolicy || '' }
        ])
        
        // Section naming
        setSectionItems([
          { id: 1, label: 'First Section Name', field: 'firstSectionName', value: settings.firstSectionName || 'Categories', icon: 'fa-layer-group', isEditing: false, lastEdited: 'Never edited' },
          { id: 2, label: 'First Section Slogan', field: 'firstSectionSlogan', value: settings.firstSectionSlogan || 'Browse by category', icon: 'fa-quote-left', isEditing: false, lastEdited: 'Never edited' },
          { id: 3, label: 'Second Section Name', field: 'secondSectionName', value: settings.secondSectionName || 'Offers', icon: 'fa-tag', isEditing: false, lastEdited: 'Never edited' },
          { id: 4, label: 'Second Section Slogan', field: 'secondSectionSlogan', value: settings.secondSectionSlogan || 'Exclusive deals for you', icon: 'fa-quote-right', isEditing: false, lastEdited: 'Never edited' },
          { id: 5, label: 'Third Section Name', field: 'thirdSectionName', value: settings.thirdSectionName || 'Featured', icon: 'fa-star', isEditing: false, lastEdited: 'Never edited' },
          { id: 6, label: 'Third Section Slogan', field: 'thirdSectionSlogan', value: settings.thirdSectionSlogan || 'Handpicked products', icon: 'fa-message', isEditing: false, lastEdited: 'Never edited' },
        ])
        
        syncedRef.current = true
      })
    }
  }, [settings])

  const openPreview = (url: string) => {
    if (url) {
      setPreviewSrc(url)
      setPreviewModal(true)
    }
  }

  // Upload file
  const uploadFile = async (file: File, type: string): Promise<string | null> => {
    const formData = new FormData()
    formData.append('file', file)
    formData.append('type', type)
    
    try {
      const response = await fetch('/api/upload', { method: 'POST', body: formData })
      const result = await response.json()
      return result.success ? result.url : null
    } catch {
      return null
    }
  }

  // Branding handlers
  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    
    showToastMsg('Uploading logo...')
    const url = await uploadFile(file, 'logo')
    if (url) {
      setLogoUrl(url)
      setLogoName(file.name)
      showToastMsg('Logo uploaded!')
    } else {
      showToastMsg('Upload failed')
    }
  }

  const handleFaviconUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    
    showToastMsg('Uploading favicon...')
    const url = await uploadFile(file, 'favicon')
    if (url) {
      setFaviconUrl(url)
      setFaviconName(file.name)
      showToastMsg('Favicon uploaded!')
    } else {
      showToastMsg('Upload failed')
    }
  }

  const saveBranding = async () => {
    setSaving(true)
    try {      
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          ...settings, 
          websiteName: websiteName,
          slogan: slogan,
          logoUrl,
          faviconUrl
        })
      })
      const data = await res.json()
      if (data.success) {
        await refetchSettings()
        setBrandingEditing(false)
        showToastMsg('Branding saved!')
      }
    } catch {
      showToastMsg('Error saving')
    }
    setSaving(false)
  }

  // Hero handlers
  const handleHeroUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return
    
    showToastMsg(`Uploading ${files.length} image(s)...`)
    
    const newImages: {name: string, url: string}[] = []
    for (let i = 0; i < files.length; i++) {
      const url = await uploadFile(files[i], `hero-${Date.now()}-${i}`)
      if (url) {
        newImages.push({ name: files[i].name, url })
      }
    }
    
    if (newImages.length > 0) {
      setHeroImages(prev => [...prev, ...newImages])
      showToastMsg(`${newImages.length} image(s) uploaded!`)
    } else {
      showToastMsg('Upload failed')
    }
  }

  const removeHeroImage = (index: number) => {
    setHeroImages(prev => prev.filter((_, i) => i !== index))
  }

  const saveHero = async () => {
    setSaving(true)
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          ...settings, 
          heroImages: JSON.stringify(heroImages.map(h => h.url)),
          heroAnimationSpeed: animationSpeed,
          heroAnimationType: animationType
        })
      })
      const data = await res.json()
      if (data.success) {
        await refetchSettings()
        setHeroEditing(false)
        showToastMsg('Hero saved!')
      }
    } catch {
      showToastMsg('Error saving')
    }
    setSaving(false)
  }

  // Delivery handlers
  const saveDelivery = async () => {
    setSaving(true)
    try {      
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          ...settings, 
          insideDhakaDelivery: insideDhaka,
          outsideDhakaDelivery: outsideDhaka,
          universalDeliveryCharge: universalCharge,
          universalDelivery: isUniversalOn,
          freeDeliveryMin: freeThreshold
        })
      })
      const data = await res.json()
      if (data.success) {
        await refetchSettings()
        setDeliveryEditing(false)
        showToastMsg('Delivery saved!')
      }
    } catch {
      showToastMsg('Error saving')
    }
    setSaving(false)
  }

  // Social handlers
  const saveSocial = async () => {
    setSaving(true)
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          ...settings, 
          phoneNumber: phone,
          whatsappNumber: whatsapp,
          facebookUrl: facebook,
          messengerUsername: messenger
        })
      })
      const data = await res.json()
      if (data.success) {
        await refetchSettings()
        setSocialEditing(false)
        showToastMsg('Social saved!')
      }
    } catch {
      showToastMsg('Error saving')
    }
    setSaving(false)
  }

  // Legal handlers
  const getActivePageName = () => legalPages.find(p => p.id === editingLegalId)?.name || ''
  const getActivePageContent = () => legalPages.find(p => p.id === editingLegalId)?.content || ''
  const updateActivePageContent = (val: string) => {
    setLegalPages(prev => prev.map(p => p.id === editingLegalId ? { ...p, content: val } : p))
  }
  const saveLegalPage = async () => {
    const page = legalPages.find(p => p.id === editingLegalId)
    if (page) {
      setSaving(true)
      try {
        const fieldMap: Record<string, string> = {
          about: 'aboutUs',
          terms: 'termsConditions',
          refund: 'refundPolicy',
          privacy: 'privacyPolicy'
        }
        await fetch('/api/settings', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...settings, [fieldMap[page.id]]: page.content })
        })
        await refetchSettings()
        showToastMsg(`${getActivePageName()} saved!`)
        setEditingLegalId(null)
      } catch {
        showToastMsg('Error saving')
      }
      setSaving(false)
    }
  }

  // Section Naming handlers
  const toggleSectionEdit = async (id: number) => {
    const item = sectionItems.find(s => s.id === id)
    
    if (item?.isEditing) {
      await saveSectionItem(id)
    } else {
      setSectionItems(prev => prev.map(s => 
        s.id === id ? { ...s, isEditing: true } : s
      ))
    }
  }

  const updateSectionValue = (id: number, newValue: string) => {
    setSectionItems(prev => prev.map(s => 
      s.id === id ? { ...s, value: newValue } : s
    ))
  }

  const saveSectionItem = async (id: number) => {
    const item = sectionItems.find(s => s.id === id)
    if (!item) return

    setSaving(true)
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...settings, [item.field]: item.value })
      })
      const data = await res.json()
      
      if (data.success) {
        await refetchSettings()
        const now = new Date()
        const timeStr = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true }).toLowerCase()
        const dateStr = now.toLocaleDateString('en-US', { day: 'numeric', month: 'long', year: 'numeric' })
        setSectionItems(prev => prev.map(s => 
          s.id === id ? { ...s, isEditing: false, lastEdited: `${dateStr} - ${timeStr}` } : s
        ))
        showToastMsg('Saved!')
      }
    } catch {
      showToastMsg('Error saving')
    }
    setSaving(false)
  }

  const handleSectionKeyDown = (e: React.KeyboardEvent, id: number) => {
    if (e.key === 'Enter') {
      toggleSectionEdit(id)
    }
  }

  const tabs: { id: SettingsTab; name: string }[] = [
    { id: 'branding', name: 'Branding' },
    { id: 'hero', name: 'Hero' },
    { id: 'delivery', name: 'Delivery' },
    { id: 'social', name: 'Social' },
    { id: 'legal', name: 'Legal' },
    { id: 'sections', name: 'Section Naming' }
  ]

  return (
    <div className="p-4 md:p-8 bg-white min-h-[calc(100vh-80px)]" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* CSS Styles */}
      <style jsx global>{`
        .table-container { border: 1px solid #cbd5e1; border-radius: 5px; overflow: hidden; }
        .settings-table { width: 100%; border-collapse: collapse; }
        .settings-table th, .settings-table td { border: 1px solid #cbd5e1; }
        .settings-table tr th:first-child, .settings-table tr td:first-child { border-left: none; }
        .settings-table tr th:last-child, .settings-table tr td:last-child { border-right: none; }
        .settings-table thead tr:first-child th { border-top: none; }
        .settings-table tbody tr:last-child td { border-bottom: none; }
        /* Single line with ellipsis */
        .single-line {
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
          max-width: 200px;
          display: inline-block;
        }
        /* Input same size as text */
        .same-input {
          font-size: 14px;
          border: none;
          outline: none;
          background: transparent;
          text-align: center;
          width: 100%;
          padding: 0;
          color: #334155;
        }
        .same-input:focus {
          outline: none;
        }
        /* Toggle switch */
        .toggle-switch {
          position: relative;
          width: 44px;
          height: 24px;
          background-color: #cbd5e1;
          border-radius: 12px;
          cursor: pointer;
          transition: background-color 0.2s;
          display: inline-block;
        }
        .toggle-switch.active {
          background-color: #16a34a;
        }
        .toggle-switch::after {
          content: '';
          position: absolute;
          top: 2px;
          left: 2px;
          width: 20px;
          height: 20px;
          background-color: white;
          border-radius: 50%;
          transition: transform 0.2s;
          box-shadow: 0 1px 3px rgba(0,0,0,0.2);
        }
        .toggle-switch.active::after {
          transform: translateX(20px);
        }
      `}</style>

      {/* Preview Modal */}
      {previewModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-90" onClick={() => setPreviewModal(false)}>
          <div className="bg-white p-2 rounded max-w-3xl relative" onClick={e => e.stopPropagation()}>
            <button onClick={() => setPreviewModal(false)} className="absolute -top-10 right-0 text-4xl text-white hover:text-gray-300">&times;</button>
            <img src={previewSrc} alt="Preview" className="max-w-full max-h-[80vh] object-contain" />
          </div>
        </div>
      )}

      <div className="max-w-6xl mx-auto">
        {/* Filter Tabs */}
        <div className="flex gap-2 mb-4 flex-wrap">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 text-sm font-medium transition-all border ${
                activeTab === tab.id
                  ? 'border-[#1e293b] text-[#1e293b] bg-[#1e293b]/5'
                  : 'border-gray-300 text-gray-600 hover:border-gray-400'
              }`}
              style={{ borderRadius: '5px' }}
            >
              {tab.name}
            </button>
          ))}
        </div>

        {/* ================= BRANDING SECTION ================= */}
        {activeTab === 'branding' && (
          <table className="w-full border-collapse border border-gray-400">
            <thead>
              <tr className="bg-gray-50">
                <th className="p-4 text-center w-1/5 font-bold border-r border-gray-400 uppercase text-xs">Website Name</th>
                <th className="p-4 text-center w-1/5 font-bold border-r border-gray-400 uppercase text-xs">Slogan</th>
                <th className="p-4 text-center w-1/5 font-bold border-r border-gray-400 uppercase text-xs">Logo</th>
                <th className="p-4 text-center w-1/5 font-bold border-r border-gray-400 uppercase text-xs">Favicon</th>
                <th className="p-4 text-center w-1/5 font-bold uppercase text-xs">Action</th>
              </tr>
            </thead>
            <tbody className="border border-gray-400">
              <tr>
                <td className="p-4 text-center border-r border-gray-400">
                  {!brandingEditing ? (
                    <span className="text-sm text-slate-700 single-line">{websiteName}</span>
                  ) : (
                    <input 
                      type="text"
                      value={websiteName}
                      onChange={(e) => setWebsiteName(e.target.value)}
                      className="same-input"
                      autoFocus
                    />
                  )}
                </td>
                <td className="p-4 text-center border-r border-gray-400">
                  {!brandingEditing ? (
                    <span className="text-sm text-slate-700 single-line">{slogan}</span>
                  ) : (
                    <input 
                      type="text"
                      value={slogan}
                      onChange={(e) => setSlogan(e.target.value)}
                      className="same-input"
                    />
                  )}
                </td>
                <td className="p-4 text-center border-r border-gray-400">
                  {!brandingEditing ? (
                    logoUrl ? (
                      <span 
                        className="text-xs text-blue-600 cursor-pointer hover:underline single-line block max-w-[150px] mx-auto"
                        onClick={() => openPreview(logoUrl)}
                        title={logoUrl}
                      >
                        {logoUrl}
                      </span>
                    ) : (
                      <span className="text-sm text-slate-400">No logo</span>
                    )
                  ) : (
                    <div className="flex flex-col items-center gap-1">
                      <input 
                        ref={logoInputRef}
                        type="file" 
                        accept="image/*"
                        onChange={handleLogoUpload} 
                        className="hidden" 
                      />
                      <button 
                        onClick={() => logoInputRef.current?.click()}
                        className="text-xs text-blue-600 hover:underline"
                      >
                        {logoUrl ? 'Change' : 'Upload'}
                      </button>
                    </div>
                  )}
                </td>
                <td className="p-4 text-center border-r border-gray-400">
                  {!brandingEditing ? (
                    faviconUrl ? (
                      <span 
                        className="text-xs text-blue-600 cursor-pointer hover:underline single-line block max-w-[150px] mx-auto"
                        onClick={() => openPreview(faviconUrl)}
                        title={faviconUrl}
                      >
                        {faviconUrl}
                      </span>
                    ) : (
                      <span className="text-sm text-slate-400">No favicon</span>
                    )
                  ) : (
                    <div className="flex flex-col items-center gap-1">
                      <input 
                        ref={faviconInputRef}
                        type="file" 
                        accept="image/*"
                        onChange={handleFaviconUpload} 
                        className="hidden" 
                      />
                      <button 
                        onClick={() => faviconInputRef.current?.click()}
                        className="text-xs text-blue-600 hover:underline"
                      >
                        {faviconUrl ? 'Change' : 'Upload'}
                      </button>
                    </div>
                  )}
                </td>
                <td className="p-4 text-center">
                  {!brandingEditing ? (
                    <button 
                      onClick={() => setBrandingEditing(true)} 
                      className="text-slate-300 hover:text-slate-900 transition-colors"
                    >
                      <i className="fa-regular fa-pen-to-square"></i>
                    </button>
                  ) : (
                    <button 
                      onClick={saveBranding} 
                      disabled={saving}
                      className="text-green-600 hover:text-green-700 transition-colors"
                    >
                      <i className="fa-solid fa-check"></i>
                    </button>
                  )}
                </td>
              </tr>
            </tbody>
          </table>
        )}

        {/* ================= HERO SECTION ================= */}
        {activeTab === 'hero' && (
          <>
            <table className="w-full border-collapse border border-gray-400">
              <thead>
                <tr className="bg-gray-50">
                  <th className="p-4 text-center w-1/5 font-bold border-r border-gray-400 uppercase text-xs">Total Items</th>
                  <th className="p-4 text-center w-1/5 font-bold border-r border-gray-400 uppercase text-xs">Speed (ms)</th>
                  <th className="p-4 text-center w-1/5 font-bold border-r border-gray-400 uppercase text-xs">Effect</th>
                  <th className="p-4 text-center w-1/5 font-bold border-r border-gray-400 uppercase text-xs">Upload</th>
                  <th className="p-4 text-center w-1/5 font-bold uppercase text-xs">Action</th>
                </tr>
              </thead>
              <tbody className="border border-gray-400">
                <tr>
                  <td className="p-4 text-center border-r border-gray-400">
                    <span className="text-sm text-slate-700">{heroImages.length}</span>
                  </td>
                  <td className="p-4 text-center border-r border-gray-400">
                    {!heroEditing ? (
                      <span className="text-sm text-slate-700">{animationSpeed}</span>
                    ) : (
                      <input 
                        type="number"
                        value={animationSpeed}
                        onChange={(e) => setAnimationSpeed(parseInt(e.target.value) || 3000)}
                        className="same-input"
                      />
                    )}
                  </td>
                  <td className="p-4 text-center border-r border-gray-400">
                    {!heroEditing ? (
                      <span className="text-sm text-slate-700 uppercase">{animationType}</span>
                    ) : (
                      <select
                        value={animationType}
                        onChange={(e) => setAnimationType(e.target.value)}
                        className="text-sm border border-gray-300 p-1 rounded"
                      >
                        <option value="Fade">Fade</option>
                        <option value="Fade In">Fade In</option>
                        <option value="Fade Out">Fade Out</option>
                      </select>
                    )}
                  </td>
                  <td className="p-4 text-center border-r border-gray-400">
                    {heroEditing ? (
                      <div>
                        <input 
                          ref={heroInputRef}
                          type="file" 
                          multiple 
                          accept="image/*"
                          onChange={handleHeroUpload} 
                          className="hidden" 
                        />
                        <button 
                          onClick={() => heroInputRef.current?.click()}
                          className="text-sm text-blue-600 hover:underline"
                        >
                          Add Images
                        </button>
                      </div>
                    ) : (
                      <span className="text-sm text-gray-400">Click edit</span>
                    )}
                  </td>
                  <td className="p-4 text-center">
                    {!heroEditing ? (
                      <button 
                        onClick={() => setHeroEditing(true)} 
                        className="text-slate-300 hover:text-slate-900 transition-colors"
                      >
                        <i className="fa-regular fa-pen-to-square"></i>
                      </button>
                    ) : (
                      <button 
                        onClick={saveHero} 
                        disabled={saving}
                        className="text-green-600 hover:text-green-700 transition-colors"
                      >
                        <i className="fa-solid fa-check"></i>
                      </button>
                    )}
                  </td>
                </tr>
              </tbody>
            </table>

            {/* Hero Images Preview */}
            {heroImages.length > 0 && (
              <div className="mt-4 flex flex-wrap gap-3">
                {heroImages.map((img, index) => (
                  <div key={index} className="relative border border-gray-200 p-1">
                    <img 
                      src={img.url} 
                      alt={img.name}
                      className="w-20 h-14 object-cover cursor-pointer"
                      onClick={() => openPreview(img.url)}
                    />
                    <span className="block text-[10px] text-slate-500 text-center mt-1 single-line">{img.name}</span>
                    {heroEditing && (
                      <button 
                        onClick={() => removeHeroImage(index)}
                        className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-[10px] hover:bg-red-600"
                      >
                        &times;
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </>
        )}

        {/* ================= DELIVERY SECTION ================= */}
        {activeTab === 'delivery' && (
          <table className="w-full border-collapse border border-gray-400">
            <thead>
              <tr className="bg-gray-50">
                <th className="p-4 text-center w-1/5 font-bold border-r border-gray-400 uppercase text-xs">Inside Dhaka</th>
                <th className="p-4 text-center w-1/5 font-bold border-r border-gray-400 uppercase text-xs">Outside Dhaka</th>
                <th className="p-4 text-center w-1/5 font-bold border-r border-gray-400 uppercase text-xs">Universal Charge</th>
                <th className="p-4 text-center w-1/5 font-bold border-r border-gray-400 uppercase text-xs">Universal ON/OFF</th>
                <th className="p-4 text-center w-1/5 font-bold uppercase text-xs">Action</th>
              </tr>
            </thead>
            <tbody className="border border-gray-400">
              <tr>
                <td className="p-4 text-center border-r border-gray-400">
                  {!deliveryEditing ? (
                    <span className="text-sm text-slate-700">TK {insideDhaka}</span>
                  ) : (
                    <div className="flex items-center justify-center gap-1">
                      <span className="text-sm text-slate-700">TK</span>
                      <input 
                        type="number"
                        value={insideDhaka}
                        onChange={(e) => setInsideDhaka(parseInt(e.target.value) || 0)}
                        className="same-input w-12"
                      />
                    </div>
                  )}
                </td>
                <td className="p-4 text-center border-r border-gray-400">
                  {!deliveryEditing ? (
                    <span className="text-sm text-slate-700">TK {outsideDhaka}</span>
                  ) : (
                    <div className="flex items-center justify-center gap-1">
                      <span className="text-sm text-slate-700">TK</span>
                      <input 
                        type="number"
                        value={outsideDhaka}
                        onChange={(e) => setOutsideDhaka(parseInt(e.target.value) || 0)}
                        className="same-input w-12"
                      />
                    </div>
                  )}
                </td>
                <td className="p-4 text-center border-r border-gray-400">
                  {!deliveryEditing ? (
                    <span className="text-sm text-slate-700">TK {universalCharge}</span>
                  ) : (
                    <div className="flex items-center justify-center gap-1">
                      <span className="text-sm text-slate-700">TK</span>
                      <input 
                        type="number"
                        value={universalCharge}
                        onChange={(e) => setUniversalCharge(parseInt(e.target.value) || 0)}
                        className="same-input w-12"
                      />
                    </div>
                  )}
                </td>
                <td className="p-4 text-center border-r border-gray-400">
                  <div 
                    className={`toggle-switch mx-auto ${isUniversalOn ? 'active' : ''}`}
                    onClick={() => {
                      if (deliveryEditing) {
                        setIsUniversalOn(!isUniversalOn)
                      }
                    }}
                  ></div>
                </td>
                <td className="p-4 text-center">
                  {!deliveryEditing ? (
                    <button 
                      onClick={() => setDeliveryEditing(true)} 
                      className="text-slate-300 hover:text-slate-900 transition-colors"
                    >
                      <i className="fa-regular fa-pen-to-square"></i>
                    </button>
                  ) : (
                    <button 
                      onClick={saveDelivery} 
                      disabled={saving}
                      className="text-green-600 hover:text-green-700 transition-colors"
                    >
                      <i className="fa-solid fa-check"></i>
                    </button>
                  )}
                </td>
              </tr>
            </tbody>
          </table>
        )}

        {/* ================= SOCIAL SECTION ================= */}
        {activeTab === 'social' && (
          <table className="w-full border-collapse border border-gray-400">
            <thead>
              <tr className="bg-gray-50">
                <th className="p-4 text-center w-1/5 font-bold border-r border-gray-400 uppercase text-xs">Phone</th>
                <th className="p-4 text-center w-1/5 font-bold border-r border-gray-400 uppercase text-xs">WhatsApp</th>
                <th className="p-4 text-center w-1/5 font-bold border-r border-gray-400 uppercase text-xs">Facebook</th>
                <th className="p-4 text-center w-1/5 font-bold border-r border-gray-400 uppercase text-xs">Messenger</th>
                <th className="p-4 text-center w-1/5 font-bold uppercase text-xs">Action</th>
              </tr>
            </thead>
            <tbody className="border border-gray-400">
              <tr>
                <td className="p-4 text-center border-r border-gray-400">
                  {!socialEditing ? (
                    <span className="text-sm text-slate-700 single-line">{phone || '-'}</span>
                  ) : (
                    <input 
                      type="text"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="same-input"
                      placeholder="Phone"
                    />
                  )}
                </td>
                <td className="p-4 text-center border-r border-gray-400">
                  {!socialEditing ? (
                    <span className="text-sm text-slate-700 single-line">{whatsapp || '-'}</span>
                  ) : (
                    <input 
                      type="text"
                      value={whatsapp}
                      onChange={(e) => setWhatsapp(e.target.value)}
                      className="same-input"
                      placeholder="WhatsApp"
                    />
                  )}
                </td>
                <td className="p-4 text-center border-r border-gray-400">
                  {!socialEditing ? (
                    <span className="text-sm text-slate-700 single-line">{facebook || '-'}</span>
                  ) : (
                    <input 
                      type="text"
                      value={facebook}
                      onChange={(e) => setFacebook(e.target.value)}
                      className="same-input"
                      placeholder="Facebook URL"
                    />
                  )}
                </td>
                <td className="p-4 text-center border-r border-gray-400">
                  {!socialEditing ? (
                    <span className="text-sm text-slate-700 single-line">{messenger || '-'}</span>
                  ) : (
                    <input 
                      type="text"
                      value={messenger}
                      onChange={(e) => setMessenger(e.target.value)}
                      className="same-input"
                      placeholder="Messenger"
                    />
                  )}
                </td>
                <td className="p-4 text-center">
                  {!socialEditing ? (
                    <button 
                      onClick={() => setSocialEditing(true)} 
                      className="text-slate-300 hover:text-slate-900 transition-colors"
                    >
                      <i className="fa-regular fa-pen-to-square"></i>
                    </button>
                  ) : (
                    <button 
                      onClick={saveSocial} 
                      disabled={saving}
                      className="text-green-600 hover:text-green-700 transition-colors"
                    >
                      <i className="fa-solid fa-check"></i>
                    </button>
                  )}
                </td>
              </tr>
            </tbody>
          </table>
        )}

        {/* ================= LEGAL SECTION ================= */}
        {activeTab === 'legal' && (
          <>
            <table className="w-full border-collapse border border-gray-400">
              <thead>
                <tr className="bg-gray-50">
                  {legalPages.map((page) => (
                    <th key={page.id} className="p-4 text-center w-1/4 font-bold border-r border-gray-400 last:border-r-0 uppercase text-xs">
                      {page.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="border border-gray-400">
                <tr>
                  {legalPages.map((page) => (
                    <td key={page.id} className="p-4 text-center border-r border-gray-400 last:border-r-0">
                      <div 
                        onClick={() => setEditingLegalId(editingLegalId === page.id ? null : page.id)}
                        className="text-sm text-blue-600 cursor-pointer hover:underline"
                      >
                        {page.content ? 'Content Written Here' : 'Click to Add'}
                      </div>
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>

            {/* Dropdown Editor Area */}
            {editingLegalId && (
              <div className="mt-4 p-6 border border-gray-400 bg-white shadow-sm">
                <div className="flex items-center gap-4 mb-3 border-b pb-2">
                  <span className="text-sm font-bold uppercase text-gray-700">{getActivePageName()}</span>
                  <button 
                    onClick={saveLegalPage}
                    disabled={saving}
                    className="text-sm font-bold text-blue-600 hover:underline"
                  >
                    {saving ? 'Saving...' : 'Save'}
                  </button>
                  <span className="text-gray-300">|</span>
                  <button 
                    onClick={() => setEditingLegalId(null)}
                    className="text-sm font-bold text-red-600 hover:underline"
                  >
                    Cancel
                  </button>
                </div>
                <textarea 
                  value={getActivePageContent()} 
                  onChange={(e) => updateActivePageContent(e.target.value)}
                  className="w-full h-64 p-3 border border-gray-200 focus:outline-blue-500 text-sm bg-transparent" 
                  placeholder="Start writing page content here..."
                />
              </div>
            )}
          </>
        )}

        {/* ================= SECTION NAMING ================= */}
        {activeTab === 'sections' && (
          <div className="table-container">
            <table className="settings-table">
              <thead className="bg-slate-50">
                <tr className="text-[11px] uppercase tracking-widest text-slate-500">
                  <th className="px-4 py-3 text-left font-bold">Setting Name</th>
                  <th className="px-4 py-3 text-center font-bold">Current Value</th>
                  <th className="px-4 py-3 text-center font-bold">Last Edited</th>
                  <th className="px-4 py-3 text-center font-bold w-16">Action</th>
                </tr>
              </thead>
              <tbody>
                {sectionItems.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/30">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-7 h-7 border border-slate-200 rounded-full flex items-center justify-center text-slate-400 flex-shrink-0">
                          <i className={`fa-solid text-[10px] ${item.icon}`}></i>
                        </div>
                        <span className="text-sm text-slate-600 whitespace-nowrap">{item.label}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-center">
                      {!item.isEditing ? (
                        <span className="text-sm text-slate-700 single-line block max-w-[200px] mx-auto">{item.value || '-'}</span>
                      ) : (
                        <input 
                          type="text" 
                          value={item.value} 
                          onChange={(e) => updateSectionValue(item.id, e.target.value)}
                          onKeyDown={(e) => handleSectionKeyDown(e, item.id)}
                          onBlur={() => saveSectionItem(item.id)}
                          className="same-input"
                          autoFocus
                          disabled={saving}
                        />
                      )}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className="text-xs text-slate-400">{item.lastEdited}</span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <button 
                        onClick={() => toggleSectionEdit(item.id)} 
                        className="text-slate-300 hover:text-slate-900 transition-colors"
                        disabled={saving}
                      >
                        <i className={`${item.isEditing ? 'fa-solid fa-check text-green-600' : 'fa-regular fa-pen-to-square'}`}></i>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

      </div>
    </div>
  )
}

export default SettingsView
