'use client'

import { useState } from 'react'
import { signIn, useSession } from 'next-auth/react'
import AdminDashboard from '@/components/admin/AdminDashboard'

export default function AdminPage() {
  const { data: session, status } = useSession()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  // Loading state while checking session
  if (status === 'loading') {
    return (
      <div className="min-h-screen bg-[#f8fafc] flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-3 border-gray-200 border-t-[#16a34a] rounded-full animate-spin"></div>
        </div>
      </div>
    )
  }

  // If authenticated, show dashboard
  if (status === 'authenticated' && session) {
    return (
      <div className="min-h-screen bg-[#f8fafc]">
        <AdminDashboard setView={() => {}} />
      </div>
    )
  }

  // Handle login form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      const result = await signIn('credentials', {
        username,
        password,
        redirect: false,
      })

      if (result?.error) {
        setError('Invalid credentials')
      }
    } catch (err) {
      setError('Error occurred')
    } finally {
      setLoading(false)
    }
  }

  // Show login form
  return (
    <div className="min-h-screen bg-[#f8fafc] flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Login Card */}
        <div className="bg-white border border-[#e2e8f0] overflow-hidden" style={{ borderRadius: '5px' }}>
          {/* Header */}
          <div className="px-6 py-5 border-b border-[#e2e8f0] text-center">
            <div className="w-12 h-12 bg-[#16a34a] rounded-lg flex items-center justify-center mx-auto mb-3">
              <i className="ri-shield-keyhole-line text-2xl text-white"></i>
            </div>
            <h1 className="text-base font-semibold text-[#0f172a]">Admin Panel</h1>
            <p className="text-xs text-[#64748b] mt-1">Enter your credentials to continue</p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            {/* Error Message */}
            {error && (
              <div className="bg-[#fef2f2] border border-[#fecaca] text-[#dc2626] px-3 py-2 text-xs flex items-center gap-2" style={{ borderRadius: '5px' }}>
                <i className="ri-error-warning-line"></i>
                {error}
              </div>
            )}

            {/* Username Field */}
            <div>
              <label className="block text-xs font-medium text-[#475569] mb-1.5">Username</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-3 py-2 border border-[#e2e8f0] text-sm outline-none focus:border-[#16a34a] transition-colors"
                style={{ borderRadius: '5px' }}
                placeholder="Username"
                required
              />
            </div>

            {/* Password Field */}
            <div>
              <label className="block text-xs font-medium text-[#475569] mb-1.5">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-3 py-2 border border-[#e2e8f0] text-sm outline-none focus:border-[#16a34a] transition-colors"
                style={{ borderRadius: '5px' }}
                placeholder="••••••••"
                required
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-[#16a34a] hover:bg-[#15803d] text-white text-sm font-medium transition-colors disabled:bg-[#cbd5e1]"
              style={{ borderRadius: '5px' }}
            >
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>
        </div>

        {/* Back to Shop Link */}
        <div className="text-center mt-4">
          <a 
            href="/" 
            className="text-xs text-[#64748b] hover:text-[#16a34a] transition-colors"
          >
            ← Back to Shop
          </a>
        </div>
      </div>
    </div>
  )
}
