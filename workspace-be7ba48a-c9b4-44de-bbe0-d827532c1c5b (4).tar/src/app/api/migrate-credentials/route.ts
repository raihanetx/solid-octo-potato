import { NextResponse } from 'next/server'
import { db } from '@/db'
import { sql } from 'drizzle-orm'

export async function GET() {
  try {
    // Add timestamp columns for credentials tracking
    const migrations = [
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS admin_username_updated_at TIMESTAMP`,
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS admin_password_updated_at TIMESTAMP`,
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS steadfast_api_updated_at TIMESTAMP`,
    ]

    for (const migration of migrations) {
      try {
        await db.execute(sql.raw(migration))
      } catch (error) {
        console.log('Migration already exists or error:', error)
      }
    }

    return NextResponse.json({
      success: true,
      message: 'Credential timestamp columns added successfully'
    })
  } catch (error) {
    console.error('Migration error:', error)
    return NextResponse.json({
      success: false,
      error: 'Migration failed'
    }, { status: 500 })
  }
}
