import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { settings } from '@/db/schema'
import { eq } from 'drizzle-orm'

// GET /api/settings
export async function GET() {
  try {
    let result = await db.select().from(settings).where(eq(settings.id, 1)).limit(1)
    
    if (result.length === 0) {
      const defaultSettings = await db.insert(settings).values({
        id: 1,
        websiteName: 'EcoMart',
        slogan: '',
        logoUrl: '',
        faviconUrl: '',
        heroImages: '[]',
        insideDhakaDelivery: 60,
        outsideDhakaDelivery: 120,
        freeDeliveryMin: 500,
        universalDelivery: false,
        universalDeliveryCharge: 60,
        whatsappNumber: '',
        phoneNumber: '',
        facebookUrl: '',
        messengerUsername: '',
        aboutUs: '',
        termsConditions: '',
        refundPolicy: '',
        privacyPolicy: '',
        adminUsername: 'admin',
        adminPassword: '',
        steadfastApiKey: '',
        steadfastSecretKey: '',
        steadfastWebhookUrl: '',
      }).returning()
      result = defaultSettings
    }
    
    return NextResponse.json({
      success: true,
      data: result[0]
    })
  } catch (error) {
    console.error('Error fetching settings:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch settings' },
      { status: 500 }
    )
  }
}

// PUT /api/settings
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const existing = await db.select().from(settings).where(eq(settings.id, 1)).limit(1)
    
    // Build update object with timestamps
    const updateData: Record<string, any> = {
      websiteName: body.websiteName,
      slogan: body.slogan,
      logoUrl: body.logoUrl,
      faviconUrl: body.faviconUrl,
      heroImages: body.heroImages,
      insideDhakaDelivery: body.insideDhakaDelivery,
      outsideDhakaDelivery: body.outsideDhakaDelivery,
      freeDeliveryMin: body.freeDeliveryMin,
      universalDelivery: body.universalDelivery,
      universalDeliveryCharge: body.universalDeliveryCharge,
      whatsappNumber: body.whatsappNumber,
      phoneNumber: body.phoneNumber,
      facebookUrl: body.facebookUrl,
      messengerUsername: body.messengerUsername,
      aboutUs: body.aboutUs,
      termsConditions: body.termsConditions,
      refundPolicy: body.refundPolicy,
      privacyPolicy: body.privacyPolicy,
    }
    
    // Add credential fields if provided
    if (body.adminUsername !== undefined) {
      updateData.adminUsername = body.adminUsername
    }
    if (body.adminPassword !== undefined) {
      updateData.adminPassword = body.adminPassword
    }
    if (body.steadfastApiKey !== undefined || body.steadfastSecretKey !== undefined || body.steadfastWebhookUrl !== undefined) {
      updateData.steadfastApiKey = body.steadfastApiKey
      updateData.steadfastSecretKey = body.steadfastSecretKey
      updateData.steadfastWebhookUrl = body.steadfastWebhookUrl
    }
    
    if (existing.length === 0) {
      const newSettings = await db.insert(settings).values({
        id: 1,
        websiteName: body.websiteName || 'EcoMart',
        slogan: body.slogan || '',
        logoUrl: body.logoUrl || '',
        faviconUrl: body.faviconUrl || '',
        heroImages: body.heroImages || '[]',
        insideDhakaDelivery: body.insideDhakaDelivery ?? 60,
        outsideDhakaDelivery: body.outsideDhakaDelivery ?? 120,
        freeDeliveryMin: body.freeDeliveryMin ?? 500,
        universalDelivery: body.universalDelivery ?? false,
        universalDeliveryCharge: body.universalDeliveryCharge ?? 60,
        whatsappNumber: body.whatsappNumber || '',
        phoneNumber: body.phoneNumber || '',
        facebookUrl: body.facebookUrl || '',
        messengerUsername: body.messengerUsername || '',
        aboutUs: body.aboutUs || '',
        termsConditions: body.termsConditions || '',
        refundPolicy: body.refundPolicy || '',
        privacyPolicy: body.privacyPolicy || '',
        adminUsername: body.adminUsername || 'admin',
        adminPassword: body.adminPassword || '',
        steadfastApiKey: body.steadfastApiKey || '',
        steadfastSecretKey: body.steadfastSecretKey || '',
        steadfastWebhookUrl: body.steadfastWebhookUrl || '',
      }).returning()
      
      return NextResponse.json({
        success: true,
        data: newSettings[0]
      })
    }
    
    const updated = await db.update(settings)
      .set(updateData)
      .where(eq(settings.id, 1))
      .returning()
    
    return NextResponse.json({
      success: true,
      data: updated[0]
    })
  } catch (error) {
    console.error('Error updating settings:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to update settings' },
      { status: 500 }
    )
  }
}
