import type { NextAuthOptions } from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'
import { db } from '@/db'
import { settings } from '@/db/schema'
import { eq } from 'drizzle-orm'

// Validate NEXTAUTH_SECRET is set
if (!process.env.NEXTAUTH_SECRET) {
  console.error('⚠️ WARNING: NEXTAUTH_SECRET is not set in .env file!')
  console.error('   Generate one with: openssl rand -base64 32')
}

// Helper function to get credentials from database
async function getAdminCredentials() {
  try {
    const result = await db.select().from(settings).where(eq(settings.id, 1)).limit(1)
    if (result.length > 0 && result[0].adminPassword) {
      // Database credentials are set and password is not empty
      return {
        username: result[0].adminUsername || 'admin',
        password: result[0].adminPassword,
        source: 'database'
      }
    }
  } catch (error) {
    console.error('Error fetching admin credentials from database:', error)
  }
  // Fallback to environment variables
  return {
    username: process.env.ADMIN_USERNAME || 'admin',
    password: process.env.ADMIN_PASSWORD || 'admin123',
    source: 'env'
  }
}

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: 'Credentials',
      credentials: {
        username: { label: 'Username', type: 'text', placeholder: 'admin' },
        password: { label: 'Password', type: 'password' }
      },
      async authorize(credentials) {
        if (!credentials?.username || !credentials?.password) {
          console.log('Missing credentials')
          return null
        }

        // Get admin credentials from database (with env fallback)
        const adminCreds = await getAdminCredentials()

        // Validate credentials
        if (credentials.username === adminCreds.username && credentials.password === adminCreds.password) {
          console.log(`✅ Admin authenticated via ${adminCreds.source}:`, credentials.username)
          return {
            id: '1',
            name: 'Admin',
            username: credentials.username,
          }
        }

        console.log('Invalid credentials for user:', credentials.username)
        return null
      }
    })
  ],
  session: {
    strategy: 'jwt',
    maxAge: 24 * 60 * 60, // 24 hours
  },
  pages: {
    signIn: '/admin',
    error: '/admin',
  },
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id
        token.username = user.username
      }
      return token
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.id as string
        session.user.username = token.username as string
      }
      return session
    }
  },
  secret: process.env.NEXTAUTH_SECRET,
  debug: process.env.NODE_ENV === 'development',
}
