'use client'

import React, { useState } from 'react'
import { useAdmin } from '@/components/admin/context/AdminContext'

const CredentialsView: React.FC = () => {
  const { settings, showToastMsg, refetchSettings } = useAdmin()

  // Edit states
  const [editUsername, setEditUsername] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [editApiKey, setEditApiKey] = useState('')
  const [editSecretKey, setEditSecretKey] = useState('')
  const [editWebhookUrl, setEditWebhookUrl] = useState('')

  // Visibility
  const [showPassword, setShowPassword] = useState(false)
  const [showApiKey, setShowApiKey] = useState(false)
  const [showSecretKey, setShowSecretKey] = useState(false)

  // Edit mode
  const [editingField, setEditingField] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [expandedApi, setExpandedApi] = useState(false)

  // Get values from settings
  const adminUsername = settings.adminUsername || 'admin'
  const adminPassword = settings.adminPassword || ''
  const apiKey = settings.steadfastApiKey || ''
  const secretKey = settings.steadfastSecretKey || ''
  const webhookUrl = settings.steadfastWebhookUrl || ''

  const openEditModal = (field: string) => {
    if (field === 'username') setEditUsername(adminUsername)
    else if (field === 'password') { setNewPassword(''); setConfirmPassword('') }
    else if (field === 'api') { setEditApiKey(apiKey); setEditSecretKey(secretKey); setEditWebhookUrl(webhookUrl) }
    setEditingField(field)
  }

  const saveUsername = async () => {
    if (!editUsername.trim()) { showToastMsg('Username cannot be empty'); return }
    setSaving(true)
    try {
      const res = await fetch('/api/settings', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...settings, adminUsername: editUsername }) })
      const data = await res.json()
      if (data.success) { await refetchSettings(); showToastMsg('Username updated'); setEditingField(null) }
      else showToastMsg('Failed to save')
    } catch { showToastMsg('Error saving') }
    setSaving(false)
  }

  const savePassword = async () => {
    if (!newPassword) { showToastMsg('Enter new password'); return }
    if (newPassword !== confirmPassword) { showToastMsg('Passwords do not match'); return }
    setSaving(true)
    try {
      const res = await fetch('/api/settings', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...settings, adminPassword: newPassword }) })
      const data = await res.json()
      if (data.success) { await refetchSettings(); showToastMsg('Password updated'); setEditingField(null); setNewPassword(''); setConfirmPassword('') }
      else showToastMsg('Failed to save')
    } catch { showToastMsg('Error saving') }
    setSaving(false)
  }

  const saveApiCredentials = async () => {
    setSaving(true)
    try {
      const res = await fetch('/api/settings', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...settings, steadfastApiKey: editApiKey, steadfastSecretKey: editSecretKey, steadfastWebhookUrl: editWebhookUrl }) })
      const data = await res.json()
      if (data.success) { await refetchSettings(); showToastMsg('API credentials saved'); setEditingField(null) }
      else showToastMsg('Failed to save')
    } catch { showToastMsg('Error saving') }
    setSaving(false)
  }

  return (
    <div className="p-4 md:p-8 bg-white min-h-[calc(100vh-80px)]" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Filter Tabs */}
      <div className="flex gap-2 mb-4 flex-wrap items-center">
        <button className="px-4 py-2 text-sm font-medium transition-all flex items-center gap-2 border border-[#16a34a] text-[#16a34a] bg-[#f0fdf4]" style={{ borderRadius: '5px' }}>
          <i className="ri-shield-keyhole-line text-sm"></i>
          Admin Credentials
        </button>
        <button className="px-4 py-2 text-sm font-medium transition-all flex items-center gap-2 border border-[#f59e0b] text-[#f59e0b] bg-[#fffbeb]" style={{ borderRadius: '5px' }}>
          <i className="ri-truck-line text-sm"></i>
          Courier API
        </button>
      </div>

      {/* Admin Credentials Table */}
      <div className="flex flex-col gap-2 mb-6">
        {/* Header */}
        <div className="grid grid-cols-5 bg-[#f1f5f9] border border-[#e2e8f0]" style={{ borderRadius: '5px' }}>
          <div className="px-4 py-3 border-r border-[#e2e8f0] text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Credential</div>
          <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Current Value</div>
          <div className="px-4 py-3 text-center text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Actions</div>
        </div>

        {/* Username Row */}
        <div className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all" style={{ borderRadius: '5px' }}>
          <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
            <div className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs bg-[#16a34a]/10 text-[#16a34a] border-2 border-[#16a34a]/20 flex-shrink-0">
              <i className="ri-user-line text-sm"></i>
            </div>
            <span className="text-[13px] font-medium text-[#1e293b]">Username</span>
          </div>
          <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] flex items-center">
            <span className="font-mono text-[#64748b] bg-[#f1f5f9] px-3 py-1.5 text-[12px]" style={{ borderRadius: '5px' }}>
              {adminUsername}
            </span>
          </div>
          <div className="px-4 py-3 flex items-center justify-center gap-1">
            <button 
              onClick={() => openEditModal('username')} 
              className="act-btn w-7 h-7 flex items-center justify-center text-gray-500 bg-gray-100 hover:bg-[#dcfce7] hover:text-[#16a34a] transition-all"
              style={{ borderRadius: '5px' }}
            >
              <i className="ri-edit-line text-sm"></i>
            </button>
          </div>
        </div>

        {/* Password Row */}
        <div className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all" style={{ borderRadius: '5px' }}>
          <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
            <div className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs bg-[#16a34a]/10 text-[#16a34a] border-2 border-[#16a34a]/20 flex-shrink-0">
              <i className="ri-lock-line text-sm"></i>
            </div>
            <span className="text-[13px] font-medium text-[#1e293b]">Password</span>
          </div>
          <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] flex items-center gap-2">
            <span className="font-mono text-[#64748b] bg-[#f1f5f9] px-3 py-1.5 text-[12px]" style={{ borderRadius: '5px' }}>
              {adminPassword ? (showPassword ? adminPassword : '••••••••') : '— Not set'}
            </span>
            {adminPassword && (
              <button 
                onClick={() => setShowPassword(!showPassword)} 
                className="w-6 h-6 flex items-center justify-center text-[#94a3b8] hover:text-[#16a34a] hover:bg-[#dcfce7] transition-all"
                style={{ borderRadius: '5px' }}
              >
                <i className={showPassword ? 'ri-eye-off-line' : 'ri-eye-line'}></i>
              </button>
            )}
          </div>
          <div className="px-4 py-3 flex items-center justify-center gap-1">
            <button 
              onClick={() => openEditModal('password')} 
              className="act-btn w-7 h-7 flex items-center justify-center text-gray-500 bg-gray-100 hover:bg-[#dcfce7] hover:text-[#16a34a] transition-all"
              style={{ borderRadius: '5px' }}
            >
              <i className="ri-key-2-line text-sm"></i>
            </button>
          </div>
        </div>
      </div>

      {/* Steadfast Courier API Table */}
      <div className="flex flex-col gap-2">
        {/* Header */}
        <div className="grid grid-cols-5 bg-[#f1f5f9] border border-[#e2e8f0]" style={{ borderRadius: '5px' }}>
          <div className="px-4 py-3 border-r border-[#e2e8f0] text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Credential</div>
          <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Current Value</div>
          <div className="px-4 py-3 text-center text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Actions</div>
        </div>

        {/* API Key Row */}
        <div className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all" style={{ borderRadius: '5px' }}>
          <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
            <div className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs bg-[#f59e0b]/10 text-[#f59e0b] border-2 border-[#f59e0b]/20 flex-shrink-0">
              <i className="ri-key-line text-sm"></i>
            </div>
            <span className="text-[13px] font-medium text-[#1e293b]">API Key</span>
          </div>
          <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] flex items-center gap-2">
            <span className="font-mono text-[#64748b] bg-[#f1f5f9] px-3 py-1.5 text-[12px] truncate max-w-[300px]" style={{ borderRadius: '5px' }}>
              {apiKey ? (showApiKey ? apiKey : '••••••••••••••••') : '— Not set'}
            </span>
            {apiKey && (
              <button 
                onClick={() => setShowApiKey(!showApiKey)} 
                className="w-6 h-6 flex items-center justify-center text-[#94a3b8] hover:text-[#f59e0b] hover:bg-[#fef3c7] transition-all"
                style={{ borderRadius: '5px' }}
              >
                <i className={showApiKey ? 'ri-eye-off-line' : 'ri-eye-line'}></i>
              </button>
            )}
          </div>
          <div className="px-4 py-3 flex items-center justify-center gap-1" rowSpan={3}>
            <button 
              onClick={() => openEditModal('api')} 
              className="act-btn w-7 h-7 flex items-center justify-center text-gray-500 bg-gray-100 hover:bg-[#fef3c7] hover:text-[#f59e0b] transition-all"
              style={{ borderRadius: '5px' }}
            >
              <i className="ri-edit-line text-sm"></i>
            </button>
          </div>
        </div>

        {/* Secret Key Row */}
        <div className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all" style={{ borderRadius: '5px' }}>
          <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
            <div className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs bg-[#f59e0b]/10 text-[#f59e0b] border-2 border-[#f59e0b]/20 flex-shrink-0">
              <i className="ri-shield-check-line text-sm"></i>
            </div>
            <span className="text-[13px] font-medium text-[#1e293b]">Secret Key</span>
          </div>
          <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] flex items-center gap-2">
            <span className="font-mono text-[#64748b] bg-[#f1f5f9] px-3 py-1.5 text-[12px] truncate max-w-[300px]" style={{ borderRadius: '5px' }}>
              {secretKey ? (showSecretKey ? secretKey : '••••••••••••••••') : '— Not set'}
            </span>
            {secretKey && (
              <button 
                onClick={() => setShowSecretKey(!showSecretKey)} 
                className="w-6 h-6 flex items-center justify-center text-[#94a3b8] hover:text-[#f59e0b] hover:bg-[#fef3c7] transition-all"
                style={{ borderRadius: '5px' }}
              >
                <i className={showSecretKey ? 'ri-eye-off-line' : 'ri-eye-line'}></i>
              </button>
            )}
          </div>
          <div className="px-4 py-3 flex items-center justify-center">
            {/* Action button in first row spans all 3 */}
          </div>
        </div>

        {/* Webhook URL Row */}
        <div className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all" style={{ borderRadius: '5px' }}>
          <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
            <div className="w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs bg-[#f59e0b]/10 text-[#f59e0b] border-2 border-[#f59e0b]/20 flex-shrink-0">
              <i className="ri-links-line text-sm"></i>
            </div>
            <span className="text-[13px] font-medium text-[#1e293b]">Webhook URL</span>
          </div>
          <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] flex items-center">
            <span className="font-mono text-[#64748b] bg-[#f1f5f9] px-3 py-1.5 text-[12px] truncate block max-w-[300px]" style={{ borderRadius: '5px' }}>
              {webhookUrl || '— Not set'}
            </span>
          </div>
          <div className="px-4 py-3 flex items-center justify-center">
            {/* Action button in first row spans all 3 */}
          </div>
        </div>

        {/* Info Row */}
        <div className="grid grid-cols-5 bg-[#fffbeb] border border-[#fcd34d]/50" style={{ borderRadius: '5px' }}>
          <div className="px-4 py-3 border-r border-[#fcd34d]/30 flex items-center gap-2">
            <i className="ri-information-line text-[#f59e0b]"></i>
            <span className="text-[12px] font-medium text-[#92400e]">Info</span>
          </div>
          <div className="px-4 py-3 col-span-4 flex items-center">
            <span className="text-[11px] text-[#92400e]">Get your API credentials from Steadfast Dashboard → Settings → API Integration</span>
          </div>
        </div>
      </div>

      {/* Edit Username Modal */}
      {editingField === 'username' && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white border border-[#e2e8f0] w-full max-w-xs overflow-hidden shadow-xl" style={{ borderRadius: '5px' }}>
            <div className="px-5 py-3 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
              <h3 className="text-[14px] font-semibold text-[#0f172a] flex items-center gap-2">
                <i className="ri-user-line text-[#16a34a]"></i>
                Edit Username
              </h3>
              <button onClick={() => setEditingField(null)} className="text-[#94a3b8] hover:text-[#64748b] transition-colors">
                <i className="ri-close-line text-lg"></i>
              </button>
            </div>
            <div className="p-5">
              <label className="block text-[11px] font-medium text-[#475569] mb-1.5">New Username</label>
              <input 
                type="text" 
                value={editUsername} 
                onChange={(e) => setEditUsername(e.target.value)} 
                className="w-full px-3 py-2.5 border border-[#e2e8f0] text-[13px] outline-none focus:border-[#16a34a] transition-all" 
                style={{ borderRadius: '5px' }} 
                autoFocus 
              />
            </div>
            <div className="px-5 py-3 border-t border-[#e2e8f0] flex justify-end gap-2 bg-[#f8fafc]">
              <button onClick={() => setEditingField(null)} className="px-4 py-2 text-[12px] font-medium text-[#64748b] hover:bg-[#e2e8f0] transition-colors" style={{ borderRadius: '5px' }}>Cancel</button>
              <button onClick={saveUsername} disabled={saving} className="px-4 py-2 bg-[#16a34a] text-white text-[12px] font-medium hover:bg-[#15803d] disabled:bg-[#cbd5e1] transition-colors flex items-center gap-1" style={{ borderRadius: '5px' }}>
                {saving && <i className="ri-loader-4-line animate-spin"></i>}
                {saving ? 'Saving...' : 'Save'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Change Password Modal */}
      {editingField === 'password' && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white border border-[#e2e8f0] w-full max-w-xs overflow-hidden shadow-xl" style={{ borderRadius: '5px' }}>
            <div className="px-5 py-3 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
              <h3 className="text-[14px] font-semibold text-[#0f172a] flex items-center gap-2">
                <i className="ri-lock-line text-[#16a34a]"></i>
                Change Password
              </h3>
              <button onClick={() => setEditingField(null)} className="text-[#94a3b8] hover:text-[#64748b] transition-colors">
                <i className="ri-close-line text-lg"></i>
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="block text-[11px] font-medium text-[#475569] mb-1.5">New Password</label>
                <input 
                  type="password" 
                  value={newPassword} 
                  onChange={(e) => setNewPassword(e.target.value)} 
                  className="w-full px-3 py-2.5 border border-[#e2e8f0] text-[13px] outline-none focus:border-[#16a34a] transition-all" 
                  style={{ borderRadius: '5px' }} 
                  placeholder="Enter new password" 
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-[#475569] mb-1.5">Confirm Password</label>
                <input 
                  type="password" 
                  value={confirmPassword} 
                  onChange={(e) => setConfirmPassword(e.target.value)} 
                  className="w-full px-3 py-2.5 border border-[#e2e8f0] text-[13px] outline-none focus:border-[#16a34a] transition-all" 
                  style={{ borderRadius: '5px' }} 
                  placeholder="Confirm new password" 
                />
                {newPassword && confirmPassword && newPassword !== confirmPassword && (
                  <p className="text-[11px] text-[#ef4444] mt-1.5 flex items-center gap-1">
                    <i className="ri-error-warning-line"></i>
                    Passwords do not match
                  </p>
                )}
              </div>
            </div>
            <div className="px-5 py-3 border-t border-[#e2e8f0] flex justify-end gap-2 bg-[#f8fafc]">
              <button onClick={() => setEditingField(null)} className="px-4 py-2 text-[12px] font-medium text-[#64748b] hover:bg-[#e2e8f0] transition-colors" style={{ borderRadius: '5px' }}>Cancel</button>
              <button 
                onClick={savePassword} 
                disabled={saving || !newPassword || newPassword !== confirmPassword} 
                className="px-4 py-2 bg-[#16a34a] text-white text-[12px] font-medium hover:bg-[#15803d] disabled:bg-[#cbd5e1] transition-colors flex items-center gap-1" 
                style={{ borderRadius: '5px' }}
              >
                {saving && <i className="ri-loader-4-line animate-spin"></i>}
                {saving ? 'Saving...' : 'Save'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit API Credentials Modal */}
      {editingField === 'api' && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white border border-[#e2e8f0] w-full max-w-md overflow-hidden shadow-xl" style={{ borderRadius: '5px' }}>
            <div className="px-5 py-3 border-b border-[#e2e8f0] flex items-center justify-between bg-[#f8fafc]">
              <h3 className="text-[14px] font-semibold text-[#0f172a] flex items-center gap-2">
                <i className="ri-truck-line text-[#f59e0b]"></i>
                Edit API Credentials
              </h3>
              <button onClick={() => setEditingField(null)} className="text-[#94a3b8] hover:text-[#64748b] transition-colors">
                <i className="ri-close-line text-lg"></i>
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="block text-[11px] font-medium text-[#475569] mb-1.5">API Key</label>
                <input 
                  type="text" 
                  value={editApiKey} 
                  onChange={(e) => setEditApiKey(e.target.value)} 
                  className="w-full px-3 py-2.5 border border-[#e2e8f0] text-[13px] outline-none focus:border-[#f59e0b] transition-all font-mono" 
                  style={{ borderRadius: '5px' }} 
                  placeholder="Enter API key" 
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-[#475569] mb-1.5">Secret Key</label>
                <input 
                  type="text" 
                  value={editSecretKey} 
                  onChange={(e) => setEditSecretKey(e.target.value)} 
                  className="w-full px-3 py-2.5 border border-[#e2e8f0] text-[13px] outline-none focus:border-[#f59e0b] transition-all font-mono" 
                  style={{ borderRadius: '5px' }} 
                  placeholder="Enter secret key" 
                />
              </div>
              <div>
                <label className="block text-[11px] font-medium text-[#475569] mb-1.5">Webhook URL</label>
                <input 
                  type="text" 
                  value={editWebhookUrl} 
                  onChange={(e) => setEditWebhookUrl(e.target.value)} 
                  className="w-full px-3 py-2.5 border border-[#e2e8f0] text-[13px] outline-none focus:border-[#f59e0b] transition-all font-mono" 
                  style={{ borderRadius: '5px' }} 
                  placeholder="https://yoursite.com/api/webhook/steadfast" 
                />
              </div>
              <div className="flex gap-2 p-3 bg-[#fffbeb] border border-[#fcd34d]" style={{ borderRadius: '5px' }}>
                <i className="ri-information-line text-[#f59e0b] text-sm flex-shrink-0 mt-0.5"></i>
                <p className="text-[11px] text-[#92400e]">Get your API credentials from Steadfast Dashboard → Settings → API Integration</p>
              </div>
            </div>
            <div className="px-5 py-3 border-t border-[#e2e8f0] flex justify-end gap-2 bg-[#f8fafc]">
              <button onClick={() => setEditingField(null)} className="px-4 py-2 text-[12px] font-medium text-[#64748b] hover:bg-[#e2e8f0] transition-colors" style={{ borderRadius: '5px' }}>Cancel</button>
              <button 
                onClick={saveApiCredentials} 
                disabled={saving} 
                className="px-4 py-2 bg-[#f59e0b] text-white text-[12px] font-medium hover:bg-[#d97706] disabled:bg-[#cbd5e1] transition-colors flex items-center gap-1" 
                style={{ borderRadius: '5px' }}
              >
                {saving && <i className="ri-loader-4-line animate-spin"></i>}
                {saving ? 'Saving...' : 'Save'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default CredentialsView
