'use client'

import React, { useState, useEffect, useMemo } from 'react'
import { motion } from 'framer-motion'
import { useAdmin } from '@/components/admin/context/AdminContext'
import { VisualCard } from './VisualCard'
import { 
  AreaChart, Area, 
  BarChart, Bar, 
  PieChart, Pie, Cell,
  ResponsiveContainer, 
  XAxis, YAxis, 
  Tooltip,
  Legend,
  ComposedChart,
  Line
} from 'recharts'
import { 
  TrendingUp, 
  Users, 
  ShoppingBag, 
  DollarSign,
  UserPlus,
  Target,
  Eye,
  Download,
  Smartphone,
  Monitor,
  Chrome,
  Apple,
  Globe,
  AlertCircle
} from 'lucide-react'

interface OverviewViewProps {
  setDashView: (view: string) => void
}

interface DashboardData {
  totalRevenue: number
  totalOrders: number
  pendingOrders: number
  canceledOrders: number
  totalCustomers: number
  newCustomers: number
  repeatCustomers: number
  totalViews: number
  uniqueProductsViewed: number
  totalCartAdds: number
  avgOrderValue: number
  conversionRate: string
  revPerVisitor: string
  topSellingProducts: Array<{ name: string; sales: number; revenue: number; category: string }>
  mostViewedProducts: Array<{ name: string; category: string; views: number }>
  topCustomers: Array<{ name: string; phone: string; totalSpent: number; orderCount: number }>
  dailyStats: Array<{ date: string; sales: number; revenue: number; orders: number; visitors: number }>
  deviceStats: {
    mobile: number
    desktop: number
    tablet: number
    ios: number
    android: number
    chrome: number
    safari: number
    other: number
    total: number
  }
  timeFrame: string
  days: number
}

type TimeFrame = 'today' | '7d' | '15d' | '30d' | '45d' | '3m' | '6m' | '1y';

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white border border-slate-200 p-3 rounded-lg backdrop-blur-md shadow-lg">
        <p className="text-[10px] uppercase tracking-tighter text-slate-400 mb-1">{label}</p>
        {payload.map((p: any, i: number) => (
          <p key={i} className="text-sm font-mono" style={{ color: p.color || p.fill }}>
            {p.name}: {typeof p.value === 'number' ? p.value.toLocaleString() : p.value}
          </p>
        ))}
      </div>
    )
  }
  return null
}

export const OverviewView: React.FC<OverviewViewProps> = ({ setDashView }) => {
  const { showToastMsg } = useAdmin()
  const [timeFrame, setTimeFrame] = useState<TimeFrame>('30d')
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [data, setData] = useState<DashboardData | null>(null)

  // Fetch dashboard data from API
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true)
      setError(null)
      try {
        const response = await fetch(`/api/dashboard?timeFrame=${timeFrame}`)
        const result = await response.json()
        
        if (result.success) {
          setData(result.data)
        } else {
          setError(result.error || 'Failed to load data')
        }
      } catch (err) {
        setError('Failed to connect to server')
        console.error('Dashboard fetch error:', err)
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [timeFrame])

  // Calculate derived stats
  const stats = useMemo(() => {
    if (!data) return null
    
    const totalVisitors = data.totalViews || 0
    const conversionRate = parseFloat(data.conversionRate) || 0
    const repeatRate = data.totalCustomers > 0 
      ? ((data.repeatCustomers / data.totalCustomers) * 100).toFixed(1) 
      : '0'
    
    // Device percentages (only show if we have data)
    const devicePct = {
      mobile: data.deviceStats.total > 0 
        ? ((data.deviceStats.mobile / data.deviceStats.total) * 100).toFixed(0) 
        : null,
      desktop: data.deviceStats.total > 0 
        ? ((data.deviceStats.desktop / data.deviceStats.total) * 100).toFixed(0) 
        : null,
      ios: data.deviceStats.total > 0 
        ? ((data.deviceStats.ios / data.deviceStats.total) * 100).toFixed(0) 
        : null,
      android: data.deviceStats.total > 0 
        ? ((data.deviceStats.android / data.deviceStats.total) * 100).toFixed(0) 
        : null,
      chrome: data.deviceStats.total > 0 
        ? ((data.deviceStats.chrome / data.deviceStats.total) * 100).toFixed(0) 
        : null,
      safari: data.deviceStats.total > 0 
        ? ((data.deviceStats.safari / data.deviceStats.total) * 100).toFixed(0) 
        : null,
    }

    return {
      totalVisitors,
      conversionRate,
      repeatRate,
      devicePct,
    }
  }, [data])

  const handleDownload = () => {
    if (!data || !data.dailyStats) return
    
    const headers = ['Date', 'Sales', 'Revenue', 'Orders', 'Visitors']
    const csvContent = [
      headers.join(','),
      ...data.dailyStats.map(row => [row.date, row.sales, row.revenue, row.orders, row.visitors].join(','))
    ].join('\n')

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    const url = URL.createObjectURL(blob)
    link.setAttribute('href', url)
    link.setAttribute('download', `krishibitan_report_${timeFrame}.csv`)
    link.style.visibility = 'hidden'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    showToastMsg('Report downloaded!')
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-slate-500 text-sm">Loading...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="flex flex-col items-center gap-3 text-center p-6">
          <AlertCircle size={48} className="text-red-500" />
          <p className="text-slate-700 font-medium">Failed to load analytics</p>
          <p className="text-slate-500 text-sm">{error}</p>
          <button 
            onClick={() => setTimeFrame(timeFrame)}
            className="px-4 py-2 bg-emerald-600 text-white hover:bg-emerald-700 transition-colors"
            style={{ borderRadius: '5px' }}
          >
            Retry
          </button>
        </div>
      </div>
    )
  }

  if (!data || !stats) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <p className="text-slate-500">No data available</p>
      </div>
    )
  }

  const showCharts = timeFrame !== 'today'

  // Customer segments for pie chart
  const customerSegments = [
    { name: 'New', value: data.newCustomers, color: '#10b981' },
    { name: 'Repeat', value: data.repeatCustomers, color: '#3b82f6' },
  ]

  return (
    <div className="min-h-screen bg-white text-slate-900 p-6 md:p-8 font-sans">
      <header className="mb-8 flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div className="space-y-2">
          <h1 className="text-2xl md:text-3xl font-semibold text-slate-900">
            Overview
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-4">
          <div className="flex bg-white p-1 rounded-xl border border-slate-200 overflow-x-auto">
            {(['today', '7d', '15d', '30d', '45d', '3m', '6m', '1y'] as TimeFrame[]).map((tf) => (
              <button
                key={tf}
                onClick={() => setTimeFrame(tf)}
                className={`px-3 py-1.5 rounded-lg text-[10px] uppercase tracking-widest transition-all whitespace-nowrap ${
                  timeFrame === tf 
                    ? 'bg-slate-900 text-white font-bold' 
                    : 'text-slate-400 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                {tf}
              </button>
            ))}
          </div>
          
          <button 
            onClick={handleDownload}
            className="flex items-center gap-2 px-4 py-2.5 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl transition-all group"
          >
            <Download size={16} className="text-emerald-600 group-hover:scale-110 transition-transform" />
            <span className="text-[10px] uppercase tracking-widest font-mono text-slate-600">Export CSV</span>
          </button>
        </div>
      </header>

      {/* Metadata Overview Bar - ALL REAL DATA */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-4">
        {[
          { label: 'Avg Order Value', value: `৳${data.avgOrderValue}`, icon: DollarSign, color: 'text-blue-600' },
          { label: 'Rev per View', value: `৳${data.revPerVisitor}`, icon: TrendingUp, color: 'text-emerald-600' },
          { label: 'Total Views', value: stats.totalVisitors.toLocaleString(), icon: Users, color: 'text-purple-600' },
          { label: 'Total Orders', value: data.totalOrders.toLocaleString(), icon: ShoppingBag, color: 'text-orange-600' },
          { label: 'Conv. Rate', value: `${stats.conversionRate}%`, icon: Target, color: 'text-rose-600' },
          { label: 'Total Customers', value: data.totalCustomers.toLocaleString(), icon: Users, color: 'text-cyan-600' },
        ].map((item, i) => (
          <motion.div
            key={item.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="bg-white p-4 rounded-xl border border-slate-200 flex items-center gap-3"
          >
            <div className={`p-2 rounded-lg bg-slate-50 ${item.color}`}>
              <item.icon size={16} />
            </div>
            <div>
              <p className="text-[9px] uppercase tracking-widest text-slate-400">{item.label}</p>
              <p className="text-sm font-mono font-bold text-slate-800">{item.value}</p>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Device & Platform Overview Bar - REAL DATA (shows "No Data" if no tracking) */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
        {[
          { label: 'Mobile Users', value: stats.devicePct.mobile, icon: Smartphone, rawValue: data.deviceStats.mobile },
          { label: 'Desktop Users', value: stats.devicePct.desktop, icon: Monitor, rawValue: data.deviceStats.desktop },
          { label: 'iOS / iPhone', value: stats.devicePct.ios, icon: Apple, rawValue: data.deviceStats.ios },
          { label: 'Android', value: stats.devicePct.android, icon: Smartphone, rawValue: data.deviceStats.android },
          { label: 'Chrome Browser', value: stats.devicePct.chrome, icon: Chrome, rawValue: data.deviceStats.chrome },
          { label: 'Safari Browser', value: stats.devicePct.safari, icon: Globe, rawValue: data.deviceStats.safari },
        ].map((item, i) => (
          <motion.div
            key={item.label}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: (i + 6) * 0.05 }}
            className="bg-white p-3 rounded-xl border border-slate-200 flex items-center gap-3"
          >
            <div className="p-1.5 rounded-lg bg-slate-50 text-slate-600">
              <item.icon size={14} />
            </div>
            <div>
              <p className="text-[8px] uppercase tracking-widest text-slate-400">{item.label}</p>
              {item.value !== null ? (
                <>
                  <p className="text-xs font-mono font-bold text-slate-700">{item.value}%</p>
                  <p className="text-[8px] text-slate-400">{item.rawValue} sessions</p>
                </>
              ) : (
                <p className="text-xs font-mono text-slate-400">No data</p>
              )}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Info banner if no device tracking */}
      {data.deviceStats.total === 0 && (
        <div className="mb-8 p-4 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-3">
          <AlertCircle size={20} className="text-amber-600 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-amber-800">Device tracking not yet configured</p>
            <p className="text-xs text-amber-600 mt-1">
              Add the visitor tracking script to your pages to collect device and browser statistics.
            </p>
          </div>
        </div>
      )}

      {/* Top 5 Lists - REAL DATA */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <VisualCard title="Top 5 Best Selling Products" delay={0.1}>
          <div className="space-y-3">
            {data.topSellingProducts.length > 0 ? data.topSellingProducts.map((product, i) => (
              <div key={product.name} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100 hover:border-slate-200 transition-all">
                <div className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 font-mono text-[10px] font-bold">
                    {i+1}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-800">{product.name}</p>
                    <p className="text-[10px] uppercase text-slate-400">{product.category}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-mono text-emerald-600 font-bold">{product.sales.toLocaleString()}</p>
                  <p className="text-[9px] uppercase text-slate-400">Units Sold</p>
                </div>
              </div>
            )) : (
              <div className="text-center py-8 text-slate-400">
                <ShoppingBag size={32} className="mx-auto mb-2 opacity-50" />
                <p className="text-sm">No sales data available</p>
                <p className="text-xs mt-1">Sales will appear here after orders are approved</p>
              </div>
            )}
          </div>
        </VisualCard>

        <VisualCard title="Top 5 Most Viewed Products" delay={0.2}>
          <div className="space-y-3">
            {data.mostViewedProducts.length > 0 ? data.mostViewedProducts.map((product, i) => (
              <div key={product.name} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100 hover:border-slate-200 transition-all">
                <div className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-mono text-[10px] font-bold">
                    {i+1}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-800">{product.name}</p>
                    <p className="text-[10px] uppercase text-slate-400">{product.category}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-mono text-blue-600 font-bold">{product.views.toLocaleString()}</p>
                  <p className="text-[9px] uppercase text-slate-400">Total Views</p>
                </div>
              </div>
            )) : (
              <div className="text-center py-8 text-slate-400">
                <Eye size={32} className="mx-auto mb-2 opacity-50" />
                <p className="text-sm">No view data available</p>
                <p className="text-xs mt-1">Views will be tracked when users browse products</p>
              </div>
            )}
          </div>
        </VisualCard>
      </div>

      {/* Top Row: Primary KPIs - REAL DATA */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <VisualCard title="Total Revenue" subtitle={`৳${data.totalRevenue.toLocaleString()}`} delay={0.3}>
          {showCharts && data.dailyStats.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.dailyStats}>
                <defs>
                  <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#059669" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#059669" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="revenue" stroke="#059669" strokeWidth={2} fillOpacity={1} fill="url(#colorRev)" />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex flex-col justify-center h-full">
              <div className="flex items-center gap-2 text-emerald-600 mb-2">
                <TrendingUp size={20} />
                <span className="text-sm font-mono font-bold">Today: ৳{data.totalRevenue.toLocaleString()}</span>
              </div>
              <p className="text-[10px] uppercase text-slate-400">From {data.totalOrders} orders</p>
            </div>
          )}
        </VisualCard>

        <VisualCard title="Total Sales Volume" subtitle={data.topSellingProducts.reduce((sum, p) => sum + p.sales, 0).toLocaleString() + ' units'} delay={0.4}>
          {showCharts && data.dailyStats.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.dailyStats}>
                <defs>
                  <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <Tooltip content={<CustomTooltip />} />
                <Area type="monotone" dataKey="orders" stroke="#2563eb" strokeWidth={2} fillOpacity={1} fill="url(#colorSales)" />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center gap-4 h-full">
              <div className="p-3 rounded-xl bg-blue-50 text-blue-600">
                <ShoppingBag size={24} />
              </div>
              <div>
                <p className="text-sm font-mono font-bold text-slate-800">{data.totalOrders} orders</p>
                <p className="text-[10px] uppercase text-slate-400">Today</p>
              </div>
            </div>
          )}
        </VisualCard>

        <VisualCard title="Total Customers" subtitle={data.totalCustomers.toLocaleString()} delay={0.5}>
          <div className="flex items-center gap-4 h-full">
            <div className="flex-1">
              <p className="text-[10px] uppercase text-slate-400 mb-1">New Customers</p>
              <p className="text-xl font-mono text-emerald-600">+{data.newCustomers}</p>
            </div>
            <div className="w-px h-8 bg-slate-200" />
            <div className="flex-1">
              <p className="text-[10px] uppercase text-slate-400 mb-1">Repeat Rate</p>
              <p className="text-xl font-mono text-blue-600">{stats.repeatRate}%</p>
            </div>
          </div>
        </VisualCard>

        <VisualCard title="Conversion Efficiency" subtitle={`${stats.conversionRate}% conversion`} delay={0.6}>
          <div className="flex flex-col justify-center h-full gap-2">
            <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(parseFloat(stats.conversionRate), 100)}%` }}
                transition={{ duration: 2, delay: 1 }}
                className="bg-emerald-500 h-full"
              />
            </div>
            <p className="text-[10px] uppercase tracking-widest text-slate-400">
              {data.totalOrders} orders from {stats.totalVisitors} views
            </p>
          </div>
        </VisualCard>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Product Performance: Sales vs Visits */}
        <VisualCard 
          title="Product Engagement: Sales vs Views" 
          className="lg:col-span-2"
          delay={0.7}
        >
          {showCharts && data.topSellingProducts.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <ComposedChart data={data.topSellingProducts}>
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: 'rgba(0,0,0,0.3)', fontSize: 10 }} 
                  tickFormatter={(value) => value.length > 10 ? value.slice(0, 10) + '...' : value}
                />
                <YAxis yAxisId="left" hide />
                <YAxis yAxisId="right" orientation="right" hide />
                <Tooltip content={<CustomTooltip />} />
                <Legend verticalAlign="top" align="right" iconType="circle" wrapperStyle={{ paddingBottom: 20, fontSize: 10, textTransform: 'uppercase', letterSpacing: 1 }} />
                <Bar yAxisId="left" dataKey="sales" name="Units Sold" fill="#10b981" radius={[4, 4, 0, 0]} barSize={40} />
                <Line yAxisId="right" type="monotone" dataKey="revenue" name="Revenue (৳)" stroke="#8b5cf6" strokeWidth={3} dot={{ r: 4, fill: '#8b5cf6' }} />
              </ComposedChart>
            </ResponsiveContainer>
          ) : data.topSellingProducts.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full py-8 text-slate-400">
              <ShoppingBag size={40} className="mb-3 opacity-50" />
              <p className="text-sm font-medium text-slate-600">No Sales Data Available</p>
              <p className="text-xs mt-1">Products will appear here once orders are placed</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-full items-center">
              {[
                { label: 'Total Views', value: stats.totalVisitors.toLocaleString(), icon: Users, color: 'text-purple-600' },
                { label: 'Total Orders', value: data.totalOrders.toLocaleString(), icon: ShoppingBag, color: 'text-emerald-600' },
                { label: 'Total Revenue', value: `৳${data.totalRevenue.toLocaleString()}`, icon: DollarSign, color: 'text-blue-600' },
              ].map((stat, i) => (
                <motion.div 
                  key={stat.label}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.1 }}
                  className="p-6 rounded-xl border border-slate-100 flex flex-col items-center text-center gap-2"
                >
                  <div className={`p-3 rounded-full bg-slate-50 ${stat.color}`}>
                    <stat.icon size={24} />
                  </div>
                  <p className="text-2xl font-light tracking-tighter text-slate-900">{stat.value}</p>
                  <p className="text-[10px] uppercase tracking-widest text-slate-400">{stat.label}</p>
                </motion.div>
              ))}
            </div>
          )}
        </VisualCard>

        {/* Customer Segmentation */}
        <VisualCard title="Customer Base Breakdown" delay={0.8}>
          {data.totalCustomers > 0 ? (
            <>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={customerSegments}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={70}
                    paddingAngle={8}
                    dataKey="value"
                  >
                    {customerSegments.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip />} />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex flex-wrap gap-4 justify-center mt-2">
                {customerSegments.map((s) => (
                  <div key={s.name} className="flex items-center gap-2">
                    <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: s.color }} />
                    <span className="text-[10px] uppercase text-slate-400">{s.name}</span>
                    <span className="text-xs font-mono text-slate-600">{s.value}</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <div className="flex flex-col items-center justify-center h-full py-8 text-slate-400">
              <Users size={40} className="mb-3 opacity-50" />
              <p className="text-sm font-medium text-slate-600">No Customers Yet</p>
              <p className="text-xs mt-1">Customer data will appear after orders</p>
            </div>
          )}
        </VisualCard>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Buying Customers */}
        <VisualCard title="Top Buying Customers" delay={0.9}>
          <div className="space-y-4">
            {data.topCustomers.length > 0 ? data.topCustomers.map((customer, i) => (
              <div key={customer.phone + i} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100 hover:border-slate-200 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 font-mono text-xs">
                    0{i+1}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-slate-800">{customer.name}</p>
                    <p className="text-[10px] uppercase text-slate-400">{customer.orderCount} Orders Placed</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-mono text-emerald-600 font-bold">৳{customer.totalSpent.toLocaleString()}</p>
                  <p className="text-[10px] uppercase text-slate-400">Total Spent</p>
                </div>
              </div>
            )) : (
              <div className="text-center py-8 text-slate-400">
                <Users size={32} className="mx-auto mb-2 opacity-50" />
                <p className="text-sm">No customer data available</p>
                <p className="text-xs mt-1">Top customers will appear after orders</p>
              </div>
            )}
          </div>
        </VisualCard>

        {/* Conversion Insights - ALL REAL DATA */}
        <VisualCard title="Sales Efficiency Insights" delay={1.0}>
          <div className="grid grid-cols-2 gap-4 h-full">
            {[
              { label: 'Avg. Conversion', value: `${stats.conversionRate}%`, icon: Target, color: 'bg-emerald-50 text-emerald-600', border: 'border-emerald-100' },
              { label: 'Views per Order', value: data.totalOrders > 0 ? Math.round(stats.totalVisitors / data.totalOrders).toString() : '0', icon: Eye, color: 'bg-blue-50 text-blue-600', border: 'border-blue-100' },
              { label: 'New Cust. Rate', value: `${data.totalCustomers > 0 ? ((data.newCustomers/data.totalCustomers)*100).toFixed(0) : 0}%`, icon: UserPlus, color: 'bg-purple-50 text-purple-600', border: 'border-purple-100' },
              { label: 'Daily Orders Avg', value: data.dailyStats.length > 0 ? Math.round(data.totalOrders / data.dailyStats.length).toString() : '0', icon: ShoppingBag, color: 'bg-orange-50 text-orange-600', border: 'border-orange-100' },
            ].map((insight, i) => (
              <motion.div 
                key={insight.label}
                whileHover={{ scale: 1.02, y: -2 }}
                className={`flex flex-col justify-center p-6 rounded-xl border ${insight.border} ${insight.color.split(' ')[0]}`}
              >
                <insight.icon className={insight.color.split(' ')[1] + " mb-2"} size={20} />
                <p className="text-2xl font-light tracking-tighter text-slate-900">{insight.value}</p>
                <p className="text-[10px] uppercase tracking-widest text-slate-400">{insight.label}</p>
              </motion.div>
            ))}
          </div>
        </VisualCard>
      </div>
    </div>
  )
}

export default OverviewView
