'use client'

import React, { useState, useRef, useEffect } from 'react'
import { useAdmin } from '@/components/admin/context/AdminContext'

type SettingsTab = 'general' | 'delivery' | 'contact' | 'offers'

const SettingsView: React.FC = () => {
  const { settings, setSettings, showToastMsg, refetchSettings } = useAdmin()
  
  const [activeTab, setActiveTab] = useState<SettingsTab>('general')
  const [universalDelivery, setUniversalDelivery] = useState(false)
  const [universalDeliveryCharge, setUniversalDeliveryCharge] = useState(60)
  const [offerTitle, setOfferTitle] = useState('')
  const [offerSlogan, setOfferSlogan] = useState('')
  const [uploading, setUploading] = useState<string | null>(null)
  const [heroImages, setHeroImages] = useState<string[]>([])
  const [saving, setSaving] = useState(false)
  const [expandedSection, setExpandedSection] = useState<string | null>('identity')

  const syncedRef = useRef(false)
  const logoInputRef = useRef<HTMLInputElement>(null)
  const faviconInputRef = useRef<HTMLInputElement>(null)
  const heroInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (!syncedRef.current) {
      setUniversalDelivery(settings.universalDelivery ?? false)
      setUniversalDeliveryCharge(settings.universalDeliveryCharge ?? 60)
      setOfferTitle(settings.offerTitle ?? 'Offers')
      setOfferSlogan(settings.offerSlogan ?? 'Exclusive deals just for you')
      
      if (settings.heroImages) {
        try {
          const parsed = typeof settings.heroImages === 'string' 
            ? JSON.parse(settings.heroImages) 
            : settings.heroImages
          setHeroImages(Array.isArray(parsed) ? parsed : [])
        } catch {
          setHeroImages([])
        }
      }
      syncedRef.current = true
    }
  }, [settings])

  const uploadImage = async (file: File, type: string): Promise<string | null> => {
    setUploading(type)
    try {
      const formData = new FormData()
      formData.append('file', file)
      formData.append('type', type)
      const response = await fetch('/api/upload', { method: 'POST', body: formData })
      const result = await response.json()
      if (result.success) return result.url
      showToastMsg(result.error || 'Upload failed')
      return null
    } catch (error) {
      showToastMsg('Failed to upload image')
      return null
    } finally {
      setUploading(null)
    }
  }

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const url = await uploadImage(file, 'logo')
    if (url) {
      setSettings({ ...settings, logoUrl: url })
      await saveSettings({ logoUrl: url })
      showToastMsg('Logo saved!')
    }
  }

  const handleFaviconUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const url = await uploadImage(file, 'favicon')
    if (url) {
      setSettings({ ...settings, faviconUrl: url })
      await saveSettings({ faviconUrl: url })
      showToastMsg('Favicon saved!')
    }
  }

  const handleHeroUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files || files.length === 0) return
    setUploading('hero')
    const newUrls: string[] = []
    for (let i = 0; i < files.length; i++) {
      const url = await uploadImage(files[i], `hero-${i}`)
      if (url) newUrls.push(url)
    }
    if (newUrls.length > 0) {
      const updated = [...heroImages, ...newUrls]
      setHeroImages(updated)
      await saveSettings({ heroImages: JSON.stringify(updated) })
      showToastMsg(`${newUrls.length} hero image(s) saved!`)
    }
    setUploading(null)
  }

  const removeHeroImage = async (index: number) => {
    const updated = heroImages.filter((_, i) => i !== index)
    setHeroImages(updated)
    await saveSettings({ heroImages: JSON.stringify(updated) })
    showToastMsg('Image removed')
  }

  const saveSettings = async (overrides: Partial<typeof settings> = {}) => {
    try {
      const response = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...settings,
          heroImages: JSON.stringify(heroImages),
          universalDelivery,
          universalDeliveryCharge,
          offerTitle,
          offerSlogan,
          ...overrides,
        }),
      })
      const result = await response.json()
      if (result.success) {
        await refetchSettings()
        return true
      }
      return false
    } catch (error) {
      return false
    }
  }

  const handleSaveAll = async () => {
    setSaving(true)
    const success = await saveSettings()
    showToastMsg(success ? 'Settings saved successfully!' : 'Failed to save settings')
    setSaving(false)
  }

  const tabs: { id: SettingsTab; label: string; icon: string; color: string }[] = [
    { id: 'general', label: 'General', icon: 'ri-settings-3-line', color: '#16a34a' },
    { id: 'delivery', label: 'Delivery', icon: 'ri-truck-line', color: '#f59e0b' },
    { id: 'contact', label: 'Contact', icon: 'ri-phone-line', color: '#3b82f6' },
    { id: 'offers', label: 'Offers', icon: 'ri-gift-2-line', color: '#8b5cf6' },
  ]

  const toggleExpand = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section)
  }

  return (
    <div className="p-4 md:p-8 bg-white min-h-[calc(100vh-80px)]" style={{ fontFamily: "'Inter', sans-serif" }}>
      {/* Filter Tabs */}
      <div className="flex gap-2 mb-4 flex-wrap items-center">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 text-sm font-medium transition-all flex items-center gap-2 border ${
              activeTab === tab.id 
                ? `border-[${tab.color}] text-[${tab.color}]` 
                : 'border-gray-300 text-gray-600 hover:border-gray-400'
            }`}
            style={{ 
              borderRadius: '5px',
              borderColor: activeTab === tab.id ? tab.color : undefined,
              color: activeTab === tab.id ? tab.color : undefined,
              backgroundColor: activeTab === tab.id ? `${tab.color}10` : undefined
            }}
          >
            <i className={`${tab.icon} text-sm`}></i>
            {tab.label}
          </button>
        ))}
        <button
          onClick={handleSaveAll}
          disabled={saving}
          className="ml-auto px-4 py-2 bg-[#16a34a] text-white text-sm font-medium hover:bg-[#15803d] transition-colors flex items-center gap-2 disabled:bg-[#cbd5e1]"
          style={{ borderRadius: '5px' }}
        >
          <i className="ri-save-line"></i>
          {saving ? 'Saving...' : 'Save All'}
        </button>
      </div>

      {/* General Tab */}
      {activeTab === 'general' && (
        <div className="flex flex-col gap-2">
          {/* Store Identity Row */}
          <div className="grid grid-cols-5 bg-[#f1f5f9] border border-[#e2e8f0]" style={{ borderRadius: '5px' }}>
            <div className="px-4 py-3 border-r border-[#e2e8f0] text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Setting</div>
            <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Value</div>
            <div className="px-4 py-3 text-center text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Actions</div>
          </div>

          {/* Website Name */}
          <div className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all" style={{ borderRadius: '5px' }}>
            <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
              <i className="ri-store-2-line text-[#16a34a]"></i>
              <span className="text-[13px] font-medium text-[#1e293b]">Website Name</span>
            </div>
            <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] flex items-center">
              <input
                type="text"
                value={settings.websiteName || ''}
                onChange={(e) => setSettings({ ...settings, websiteName: e.target.value })}
                className="w-full px-3 py-2 bg-white border border-[#e2e8f0] text-[13px] outline-none focus:border-[#16a34a] transition-all"
                style={{ borderRadius: '5px' }}
                placeholder="Your store name"
              />
            </div>
            <div className="px-4 py-3 flex items-center justify-center">
              <span className="text-[11px] text-[#94a3b8]">Auto-save</span>
            </div>
          </div>

          {/* Slogan */}
          <div className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all" style={{ borderRadius: '5px' }}>
            <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
              <i className="ri-chat-quote-line text-[#16a34a]"></i>
              <span className="text-[13px] font-medium text-[#1e293b]">Slogan</span>
            </div>
            <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] flex items-center">
              <input
                type="text"
                value={settings.slogan || ''}
                onChange={(e) => setSettings({ ...settings, slogan: e.target.value })}
                className="w-full px-3 py-2 bg-white border border-[#e2e8f0] text-[13px] outline-none focus:border-[#16a34a] transition-all"
                style={{ borderRadius: '5px' }}
                placeholder="Your store tagline"
              />
            </div>
            <div className="px-4 py-3 flex items-center justify-center">
              <span className="text-[11px] text-[#94a3b8]">Auto-save</span>
            </div>
          </div>

          {/* Logo */}
          <div className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all" style={{ borderRadius: '5px' }}>
            <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
              <i className="ri-image-line text-[#16a34a]"></i>
              <span className="text-[13px] font-medium text-[#1e293b]">Logo</span>
            </div>
            <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] flex items-center gap-4">
              <div className="w-12 h-12 bg-[#f8fafc] border border-[#e2e8f0] flex items-center justify-center overflow-hidden" style={{ borderRadius: '5px' }}>
                {settings.logoUrl ? (
                  <img src={settings.logoUrl} alt="Logo" className="max-w-full max-h-full object-contain p-1" />
                ) : (
                  <i className="ri-image-line text-[#cbd5e1]"></i>
                )}
              </div>
              <input ref={logoInputRef} type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
              <button
                onClick={() => logoInputRef.current?.click()}
                disabled={uploading === 'logo'}
                className="px-3 py-2 bg-[#0f172a] text-white text-[11px] font-medium hover:bg-[#1e293b] transition-colors disabled:bg-[#cbd5e1]"
                style={{ borderRadius: '5px' }}
              >
                {uploading === 'logo' ? 'Uploading...' : 'Upload'}
              </button>
            </div>
            <div className="px-4 py-3 flex items-center justify-center">
              <span className="text-[11px] text-[#94a3b8]">PNG, JPG</span>
            </div>
          </div>

          {/* Favicon */}
          <div className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all" style={{ borderRadius: '5px' }}>
            <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
              <i className="ri-global-line text-[#16a34a]"></i>
              <span className="text-[13px] font-medium text-[#1e293b]">Favicon</span>
            </div>
            <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] flex items-center gap-4">
              <div className="w-12 h-12 bg-[#f8fafc] border border-[#e2e8f0] flex items-center justify-center overflow-hidden" style={{ borderRadius: '5px' }}>
                {settings.faviconUrl ? (
                  <img src={settings.faviconUrl} alt="Favicon" className="max-w-full max-h-full object-contain p-1" />
                ) : (
                  <i className="ri-global-line text-[#cbd5e1]"></i>
                )}
              </div>
              <input ref={faviconInputRef} type="file" accept="image/*,.ico" onChange={handleFaviconUpload} className="hidden" />
              <button
                onClick={() => faviconInputRef.current?.click()}
                disabled={uploading === 'favicon'}
                className="px-3 py-2 bg-[#0f172a] text-white text-[11px] font-medium hover:bg-[#1e293b] transition-colors disabled:bg-[#cbd5e1]"
                style={{ borderRadius: '5px' }}
              >
                {uploading === 'favicon' ? 'Uploading...' : 'Upload'}
              </button>
            </div>
            <div className="px-4 py-3 flex items-center justify-center">
              <span className="text-[11px] text-[#94a3b8]">ICO, PNG</span>
            </div>
          </div>

          {/* Hero Banners - Expandable */}
          <div className="flex flex-col">
            <div 
              className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all cursor-pointer" 
              style={{ borderRadius: '5px' }}
              onClick={() => toggleExpand('hero')}
            >
              <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
                <i className="ri-image-add-line text-[#16a34a]"></i>
                <span className="text-[13px] font-medium text-[#1e293b]">Hero Banners</span>
              </div>
              <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] flex items-center">
                <span className="text-[12px] text-[#64748b]">{heroImages.length} image(s) uploaded</span>
              </div>
              <div className="px-4 py-3 flex items-center justify-center">
                <i className="ri-arrow-down-s-line text-gray-400 transition-transform duration-200" style={{ transform: expandedSection === 'hero' ? 'rotate(180deg)' : 'rotate(0deg)' }}></i>
              </div>
            </div>

            {expandedSection === 'hero' && (
              <div className="bg-white border border-[#e2e8f0] mt-2 p-4" style={{ borderRadius: '5px' }}>
                {heroImages.length > 0 && (
                  <div className="grid grid-cols-4 md:grid-cols-6 gap-3 mb-4">
                    {heroImages.map((url, index) => (
                      <div key={index} className="relative group">
                        <img src={url} alt={`Hero ${index + 1}`} className="w-full h-16 object-cover border border-[#e2e8f0]" style={{ borderRadius: '5px' }} />
                        <button onClick={() => removeHeroImage(index)} className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-[#ef4444] text-white rounded-full flex items-center justify-center text-[10px] opacity-0 group-hover:opacity-100 transition-opacity">
                          <i className="ri-close-line"></i>
                        </button>
                      </div>
                    ))}
                  </div>
                )}
                <input ref={heroInputRef} type="file" accept="image/*" multiple onChange={handleHeroUpload} className="hidden" />
                <button onClick={() => heroInputRef.current?.click()} disabled={uploading === 'hero'} className="w-full py-3 border-2 border-dashed border-[#e2e8f0] text-[12px] text-[#64748b] hover:border-[#16a34a] hover:text-[#16a34a] hover:bg-[#f0fdf4] transition-all flex items-center justify-center gap-2" style={{ borderRadius: '5px' }}>
                  <i className="ri-add-line"></i>
                  {uploading === 'hero' ? 'Uploading...' : 'Add Hero Images'}
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Delivery Tab */}
      {activeTab === 'delivery' && (
        <div className="flex flex-col gap-2">
          <div className="grid grid-cols-5 bg-[#f1f5f9] border border-[#e2e8f0]" style={{ borderRadius: '5px' }}>
            <div className="px-4 py-3 border-r border-[#e2e8f0] text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Setting</div>
            <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Value</div>
            <div className="px-4 py-3 text-center text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Status</div>
          </div>

          {/* Universal Delivery Toggle */}
          <div className="grid grid-cols-5 bg-[#f0fdf4] border border-[#16a34a]/30 hover:border-[#16a34a] transition-all" style={{ borderRadius: '5px' }}>
            <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
              <i className="ri-equal-line text-[#16a34a]"></i>
              <span className="text-[13px] font-medium text-[#1e293b]">Universal Charge</span>
            </div>
            <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] flex items-center">
              <span className="text-[12px] text-[#64748b]">Apply same delivery rate for all locations</span>
            </div>
            <div className="px-4 py-3 flex items-center justify-center">
              <button onClick={() => setUniversalDelivery(!universalDelivery)} className={`relative w-10 h-5 rounded-full transition-colors ${universalDelivery ? 'bg-[#16a34a]' : 'bg-[#e2e8f0]'}`}>
                <div className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${universalDelivery ? 'translate-x-5' : 'translate-x-0.5'}`} />
              </button>
            </div>
          </div>

          {universalDelivery ? (
            <div className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all" style={{ borderRadius: '5px' }}>
              <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
                <i className="ri-money-dollar-circle-line text-[#f59e0b]"></i>
                <span className="text-[13px] font-medium text-[#1e293b]">Charge Amount</span>
              </div>
              <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] flex items-center gap-2">
                <span className="text-[#64748b]">৳</span>
                <input type="number" value={universalDeliveryCharge} onChange={(e) => setUniversalDeliveryCharge(parseInt(e.target.value) || 0)} className="w-24 px-3 py-2 bg-[#f0fdf4] border-2 border-[#16a34a] text-[13px] outline-none" style={{ borderRadius: '5px' }} />
              </div>
              <div className="px-4 py-3 flex items-center justify-center">
                <span className="px-2 py-1 bg-green-100 text-green-600 text-[10px] font-medium" style={{ borderRadius: '3px' }}>Active</span>
              </div>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all" style={{ borderRadius: '5px' }}>
                <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
                  <i className="ri-map-pin-line text-[#f59e0b]"></i>
                  <span className="text-[13px] font-medium text-[#1e293b]">Inside Dhaka</span>
                </div>
                <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] flex items-center gap-2">
                  <span className="text-[#64748b]">৳</span>
                  <input type="number" value={settings.insideDhakaDelivery || 60} onChange={(e) => setSettings({ ...settings, insideDhakaDelivery: parseInt(e.target.value) || 0 })} className="w-24 px-3 py-2 bg-white border border-[#e2e8f0] text-[13px] outline-none focus:border-[#16a34a] transition-all" style={{ borderRadius: '5px' }} />
                </div>
                <div className="px-4 py-3 flex items-center justify-center">
                  <span className="px-2 py-1 bg-amber-100 text-amber-600 text-[10px] font-medium" style={{ borderRadius: '3px' }}>Zone A</span>
                </div>
              </div>

              <div className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all" style={{ borderRadius: '5px' }}>
                <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
                  <i className="ri-map-pin-2-line text-[#f59e0b]"></i>
                  <span className="text-[13px] font-medium text-[#1e293b]">Outside Dhaka</span>
                </div>
                <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] flex items-center gap-2">
                  <span className="text-[#64748b]">৳</span>
                  <input type="number" value={settings.outsideDhakaDelivery || 120} onChange={(e) => setSettings({ ...settings, outsideDhakaDelivery: parseInt(e.target.value) || 0 })} className="w-24 px-3 py-2 bg-white border border-[#e2e8f0] text-[13px] outline-none focus:border-[#16a34a] transition-all" style={{ borderRadius: '5px' }} />
                </div>
                <div className="px-4 py-3 flex items-center justify-center">
                  <span className="px-2 py-1 bg-blue-100 text-blue-600 text-[10px] font-medium" style={{ borderRadius: '3px' }}>Zone B</span>
                </div>
              </div>
            </>
          )}

          <div className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all" style={{ borderRadius: '5px' }}>
            <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
              <i className="ri-gift-line text-[#f59e0b]"></i>
              <span className="text-[13px] font-medium text-[#1e293b]">Free Delivery Min</span>
            </div>
            <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] flex items-center gap-2">
              <span className="text-[#64748b]">৳</span>
              <input type="number" value={settings.freeDeliveryMin || 500} onChange={(e) => setSettings({ ...settings, freeDeliveryMin: parseInt(e.target.value) || 0 })} className="w-24 px-3 py-2 bg-white border border-[#e2e8f0] text-[13px] outline-none focus:border-[#16a34a] transition-all" style={{ borderRadius: '5px' }} />
              <span className="text-[11px] text-[#94a3b8]">Orders above this qualify for free delivery</span>
            </div>
            <div className="px-4 py-3 flex items-center justify-center">
              <span className="px-2 py-1 bg-purple-100 text-purple-600 text-[10px] font-medium" style={{ borderRadius: '3px' }}>Threshold</span>
            </div>
          </div>
        </div>
      )}

      {/* Contact Tab */}
      {activeTab === 'contact' && (
        <div className="flex flex-col gap-2">
          <div className="grid grid-cols-5 bg-[#f1f5f9] border border-[#e2e8f0]" style={{ borderRadius: '5px' }}>
            <div className="px-4 py-3 border-r border-[#e2e8f0] text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Channel</div>
            <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Value</div>
            <div className="px-4 py-3 text-center text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Type</div>
          </div>

          <div className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all" style={{ borderRadius: '5px' }}>
            <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
              <i className="ri-whatsapp-line text-[#25D366]"></i>
              <span className="text-[13px] font-medium text-[#1e293b]">WhatsApp</span>
            </div>
            <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] flex items-center">
              <input type="text" value={settings.whatsappNumber || ''} onChange={(e) => setSettings({ ...settings, whatsappNumber: e.target.value })} className="w-full max-w-xs px-3 py-2 bg-white border border-[#e2e8f0] text-[13px] outline-none focus:border-[#16a34a] transition-all" style={{ borderRadius: '5px' }} placeholder="+8801xxxxxxxxx" />
            </div>
            <div className="px-4 py-3 flex items-center justify-center">
              <span className="px-2 py-1 bg-green-100 text-green-600 text-[10px] font-medium" style={{ borderRadius: '3px' }}>Chat</span>
            </div>
          </div>

          <div className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all" style={{ borderRadius: '5px' }}>
            <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
              <i className="ri-phone-line text-[#3b82f6]"></i>
              <span className="text-[13px] font-medium text-[#1e293b]">Phone</span>
            </div>
            <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] flex items-center">
              <input type="text" value={settings.phoneNumber || ''} onChange={(e) => setSettings({ ...settings, phoneNumber: e.target.value })} className="w-full max-w-xs px-3 py-2 bg-white border border-[#e2e8f0] text-[13px] outline-none focus:border-[#16a34a] transition-all" style={{ borderRadius: '5px' }} placeholder="+8801xxxxxxxxx" />
            </div>
            <div className="px-4 py-3 flex items-center justify-center">
              <span className="px-2 py-1 bg-blue-100 text-blue-600 text-[10px] font-medium" style={{ borderRadius: '3px' }}>Call</span>
            </div>
          </div>

          <div className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all" style={{ borderRadius: '5px' }}>
            <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
              <i className="ri-facebook-fill text-[#1877F2]"></i>
              <span className="text-[13px] font-medium text-[#1e293b]">Facebook</span>
            </div>
            <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] flex items-center">
              <input type="text" value={settings.facebookUrl || ''} onChange={(e) => setSettings({ ...settings, facebookUrl: e.target.value })} className="w-full max-w-md px-3 py-2 bg-white border border-[#e2e8f0] text-[13px] outline-none focus:border-[#16a34a] transition-all" style={{ borderRadius: '5px' }} placeholder="https://facebook.com/yourpage" />
            </div>
            <div className="px-4 py-3 flex items-center justify-center">
              <span className="px-2 py-1 bg-blue-100 text-blue-700 text-[10px] font-medium" style={{ borderRadius: '3px' }}>Social</span>
            </div>
          </div>

          <div className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all" style={{ borderRadius: '5px' }}>
            <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
              <i className="ri-messenger-line text-[#0099FF]"></i>
              <span className="text-[13px] font-medium text-[#1e293b]">Messenger</span>
            </div>
            <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] flex items-center">
              <input type="text" value={settings.messengerUsername || ''} onChange={(e) => setSettings({ ...settings, messengerUsername: e.target.value })} className="w-full max-w-xs px-3 py-2 bg-white border border-[#e2e8f0] text-[13px] outline-none focus:border-[#16a34a] transition-all" style={{ borderRadius: '5px' }} placeholder="yourpage" />
            </div>
            <div className="px-4 py-3 flex items-center justify-center">
              <span className="px-2 py-1 bg-cyan-100 text-cyan-600 text-[10px] font-medium" style={{ borderRadius: '3px' }}>Chat</span>
            </div>
          </div>
        </div>
      )}

      {/* Offers Tab */}
      {activeTab === 'offers' && (
        <div className="flex flex-col gap-2">
          <div className="grid grid-cols-5 bg-[#f1f5f9] border border-[#e2e8f0]" style={{ borderRadius: '5px' }}>
            <div className="px-4 py-3 border-r border-[#e2e8f0] text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Setting</div>
            <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Value</div>
            <div className="px-4 py-3 text-center text-[11px] font-semibold uppercase tracking-wide text-[#475569]">Info</div>
          </div>

          <div className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all" style={{ borderRadius: '5px' }}>
            <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
              <i className="ri-text text-[#8b5cf6]"></i>
              <span className="text-[13px] font-medium text-[#1e293b]">Section Title</span>
            </div>
            <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] flex items-center">
              <input type="text" value={offerTitle} onChange={(e) => setOfferTitle(e.target.value)} className="w-full max-w-xs px-3 py-2 bg-white border border-[#e2e8f0] text-[13px] outline-none focus:border-[#8b5cf6] transition-all" style={{ borderRadius: '5px' }} placeholder="Offers" />
            </div>
            <div className="px-4 py-3 flex items-center justify-center">
              <span className="text-[11px] text-[#94a3b8]">Heading</span>
            </div>
          </div>

          <div className="grid grid-cols-5 bg-white border border-[#e2e8f0] hover:border-[#94a3b8] transition-all" style={{ borderRadius: '5px' }}>
            <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
              <i className="ri-quote-text text-[#8b5cf6]"></i>
              <span className="text-[13px] font-medium text-[#1e293b]">Section Slogan</span>
            </div>
            <div className="px-4 py-3 col-span-3 border-r border-[#e2e8f0] flex items-center">
              <input type="text" value={offerSlogan} onChange={(e) => setOfferSlogan(e.target.value)} className="w-full max-w-md px-3 py-2 bg-white border border-[#e2e8f0] text-[13px] outline-none focus:border-[#8b5cf6] transition-all" style={{ borderRadius: '5px' }} placeholder="Exclusive deals just for you" />
            </div>
            <div className="px-4 py-3 flex items-center justify-center">
              <span className="text-[11px] text-[#94a3b8]">Subtext</span>
            </div>
          </div>

          <div className="grid grid-cols-5 bg-[#faf5ff] border border-[#8b5cf6]/30" style={{ borderRadius: '5px' }}>
            <div className="px-4 py-3 border-r border-[#e2e8f0] flex items-center gap-2">
              <i className="ri-information-line text-[#8b5cf6]"></i>
              <span className="text-[13px] font-medium text-[#6b21a8]">Info</span>
            </div>
            <div className="px-4 py-3 col-span-4 flex items-center">
              <span className="text-[12px] text-[#7c3aed]">The offer section displays products marked with special discounts. Manage products from the Products section.</span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default SettingsView
