import { drizzle } from 'drizzle-orm/neon-http'
import { neon } from '@neondatabase/serverless'
import * as schema from './schema'

// Neon Pooled Connection URL (fast, no cold starts)
const NEON_POOLED_URL = 'postgresql://neondb_owner:npg_fpYOD6th3nBT@ep-misty-mouse-a17jt54s-pooler.ap-southeast-1.aws.neon.tech/neondb?sslmode=require'

// SMART: Use env if valid PostgreSQL URL, otherwise use pooled URL
function getDatabaseUrl(): string {
  const envUrl = process.env.DATABASE_URL
  
  // Only use env URL if it's a valid PostgreSQL URL
  if (envUrl && (envUrl.startsWith('postgresql://') || envUrl.startsWith('postgres://'))) {
    return envUrl
  }
  
  // Fall back to pooled URL
  return NEON_POOLED_URL
}

const DATABASE_URL = getDatabaseUrl()

// SMART: Single neon instance with connection pooling
const sql = neon(DATABASE_URL, {
  fetchConnectionCache: true,
})

// SMART: Single drizzle instance
export const db = drizzle(sql, { schema })

// =============================================
// SMART: Global caches that persist across requests
// =============================================

declare global {
  var __settingsCache: { data: any; timestamp: number } | undefined
  var __shopDataCache: { data: any; timestamp: number } | undefined
  var __dashboardCache: { data: any; timestamp: number; timeFrame: string } | undefined
  var __courierCredentials: { data: any; timestamp: number } | undefined
}

// Cache getters/setters
export function getCachedSettings() {
  return globalThis.__settingsCache || null
}

export function setCachedSettings(data: any) {
  globalThis.__settingsCache = { data, timestamp: Date.now() }
}

export function getCachedShopData() {
  return globalThis.__shopDataCache || null
}

export function setCachedShopData(data: any) {
  globalThis.__shopDataCache = { data, timestamp: Date.now() }
}

export function getCachedDashboard(timeFrame: string) {
  const cache = globalThis.__dashboardCache
  if (cache && cache.timeFrame === timeFrame) {
    return cache
  }
  return null
}

export function setCachedDashboard(data: any, timeFrame: string) {
  globalThis.__dashboardCache = { data, timestamp: Date.now(), timeFrame }
}

export function getCachedCourierCredentials() {
  return globalThis.__courierCredentials || null
}

export function setCachedCourierCredentials(data: any) {
  globalThis.__courierCredentials = { data, timestamp: Date.now() }
}

// Re-export schema
export * from './schema'
export type Database = typeof db
