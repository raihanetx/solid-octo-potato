import { NextResponse } from 'next/server'
import { db } from '@/db'
import { sql } from 'drizzle-orm'

export async function GET() {
  try {
    // Add new columns to settings table
    const alterStatements = [
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS admin_username TEXT DEFAULT 'admin'`,
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS admin_password TEXT`,
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS steadfast_api_key TEXT`,
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS steadfast_secret_key TEXT`,
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS steadfast_webhook_url TEXT`,
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS admin_username_updated_at TEXT`,
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS admin_password_updated_at TEXT`,
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS steadfast_api_updated_at TEXT`,
      // Cloudinary columns
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS cloudinary_cloud_name TEXT`,
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS cloudinary_api_key TEXT`,
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS cloudinary_api_secret TEXT`,
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS cloudinary_updated_at TEXT`,
    ]

    const results: string[] = []

    for (const statement of alterStatements) {
      try {
        await db.execute(sql.raw(statement))
        results.push(`✓ ${statement.split('ADD COLUMN IF NOT EXISTS ')[1]?.split(' ')[0] || 'column'}`)
      } catch (err) {
        // Column might already exist, continue
        const errMsg = String(err)
        if (errMsg.includes('already exists') || errMsg.includes('duplicate')) {
          results.push(`→ Column already exists`)
        } else {
          results.push(`⚠ ${String(err)}`)
        }
      }
    }

    return NextResponse.json({
      success: true,
      message: 'Settings table migration completed',
      results
    })
  } catch (error) {
    console.error('Migration error:', error)
    return NextResponse.json({
      success: false,
      error: String(error)
    }, { status: 500 })
  }
}
