/**
 * Clear Cloudinary Credentials
 * Use when stored credentials are invalid
 */
import { NextResponse } from 'next/server'
import { db } from '@/db'
import { settings } from '@/db/schema'
import { eq } from 'drizzle-orm'

export async function POST() {
  try {
    await db.update(settings)
      .set({
        cloudinaryCloudName: '',
        cloudinaryApiKey: '',
        cloudinaryApiSecret: '',
        cloudinaryUpdatedAt: new Date().toISOString()
      })
      .where(eq(settings.id, 1))
    
    // Clear cache
    globalThis.__settingsCache = undefined
    
    return NextResponse.json({
      success: true,
      message: 'Cloudinary credentials cleared. Please enter fresh credentials from your Cloudinary dashboard.'
    })
  } catch (error) {
    console.error('Failed to clear Cloudinary credentials:', error)
    return NextResponse.json({
      success: false,
      error: 'Failed to clear credentials'
    })
  }
}
