import { NextResponse } from 'next/server'
import { neon } from '@neondatabase/serverless'

// This endpoint checks the actual database schema
export async function GET() {
  try {
    const connectionString = 'postgresql://neondb_owner:npg_fpYOD6th3nBT@ep-misty-mouse-a17jt54s.ap-southeast-1.aws.neon.tech/neondb?sslmode=require'
    const sql = neon(connectionString)
    
    // Get all columns from settings table
    const columns = await sql.query(`
      SELECT column_name, data_type, column_default 
      FROM information_schema.columns 
      WHERE table_name = 'settings' 
      ORDER BY ordinal_position
    `)
    
    return NextResponse.json({ 
      success: true, 
      columns
    })
  } catch (error: unknown) {
    const err = error as Error
    return NextResponse.json({ 
      success: false, 
      error: err.message 
    }, { status: 500 })
  }
}
