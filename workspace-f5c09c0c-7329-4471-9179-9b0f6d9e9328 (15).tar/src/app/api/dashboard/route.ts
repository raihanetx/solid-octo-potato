import { NextRequest, NextResponse } from 'next/server'
import { db, getCachedDashboard, setCachedDashboard } from '@/db'
import { 
  orders, orderItems, products, productViews, cartEvents
} from '@/db/schema'
import { eq, gte } from 'drizzle-orm'

// Cache TTL: 30 seconds
const CACHE_TTL = 30 * 1000

// GET /api/dashboard - SMART: Global cache + parallel queries
export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const timeFrame = searchParams.get('timeFrame') || '30d'

  const now = Date.now()
  
  // Check global cache
  const cached = getCachedDashboard(timeFrame)
  if (cached && (now - cached.timestamp) < CACHE_TTL) {
    return NextResponse.json({
      success: true,
      cached: true,
      data: cached.data
    })
  }

  try {
    // Calculate date range
    const currentDate = new Date()
    let days = 30
    if (timeFrame === 'today') days = 1
    else if (timeFrame === '7d') days = 7
    else if (timeFrame === '15d') days = 15
    else if (timeFrame === '30d') days = 30
    else if (timeFrame === '45d') days = 45
    else if (timeFrame === '3m') days = 90
    else if (timeFrame === '6m') days = 180
    else if (timeFrame === '1y') days = 365

    const startDate = new Date(currentDate)
    startDate.setDate(startDate.getDate() - (days - 1))
    startDate.setHours(0, 0, 0, 0)
    const startDateStr = startDate.toISOString().split('T')[0]

    // SMART: ALL queries in PARALLEL
    const [allOrders, allProductViews, allOrderItems, allProducts, cartAdditions] = await Promise.all([
      db.select().from(orders),
      db.select().from(productViews).where(gte(productViews.date, startDateStr)),
      db.select().from(orderItems),
      db.select().from(products),
      db.select().from(cartEvents).where(eq(cartEvents.action, 'add')),
    ])

    // Filter orders by time frame (in memory)
    const filteredOrders = allOrders.filter(o => {
      if (!o.createdAt) return false
      return new Date(o.createdAt) >= startDate
    })

    const approvedOrders = filteredOrders.filter(o => o.status === 'approved')
    const approvedOrderIds = new Set(approvedOrders.map(o => o.id))

    // Calculate revenue
    const totalRevenue = approvedOrders.reduce((sum, o) => {
      return sum + Math.round(parseFloat(String(o.total)) || 0)
    }, 0)

    const totalOrdersCount = approvedOrders.length
    const pendingOrdersCount = filteredOrders.filter(o => o.status === 'pending').length
    const canceledOrdersCount = filteredOrders.filter(o => o.status === 'canceled').length

    // Customer metrics
    const customerMap: Record<string, { count: number; totalSpent: number; name: string }> = {}
    
    for (const order of allOrders) {
      const phone = order.phone?.replace(/\D/g, '')
      if (phone) {
        if (!customerMap[phone]) {
          customerMap[phone] = { count: 0, totalSpent: 0, name: order.customerName || 'Unknown' }
        }
        customerMap[phone].count += 1
        customerMap[phone].totalSpent += Math.round(parseFloat(String(order.total)) || 0)
        customerMap[phone].name = order.customerName || customerMap[phone].name
      }
    }

    const totalCustomers = Object.keys(customerMap).length
    const repeatCustomersCount = Object.values(customerMap).filter(c => c.count > 1).length
    const newCustomers = totalCustomers - repeatCustomersCount

    const topCustomers = Object.entries(customerMap)
      .map(([phone, data]) => ({
        name: data.name,
        phone: phone,
        totalSpent: data.totalSpent,
        orderCount: data.count
      }))
      .sort((a, b) => b.totalSpent - a.totalSpent)
      .slice(0, 5)

    // Product views
    const totalViews = allProductViews.reduce((sum, v) => sum + (v.viewCount || 0), 0)
    const uniqueProductsViewed = new Set(allProductViews.map(v => v.productId)).size

    // Product lookup map
    const productLookup = new Map(allProducts.map(p => [p.id, p]))

    // Product sales
    const productSales: Record<string, { name: string; sales: number; revenue: number; category: string }> = {}
    
    for (const item of allOrderItems) {
      if (!approvedOrderIds.has(item.orderId || '')) continue
      
      const name = item.name
      if (!productSales[name]) {
        const product = item.productId ? productLookup.get(item.productId) : null
        productSales[name] = {
          name,
          sales: 0,
          revenue: 0,
          category: product?.category || 'Other'
        }
      }
      productSales[name].sales += item.qty
      productSales[name].revenue += Math.round(parseFloat(String(item.basePrice)) || 0) * item.qty
    }

    const topSellingProducts = Object.values(productSales)
      .sort((a, b) => b.sales - a.sales)
      .slice(0, 5)

    // Product view counts
    const productViewCounts: Record<number, number> = {}
    for (const v of allProductViews) {
      productViewCounts[v.productId] = (productViewCounts[v.productId] || 0) + (v.viewCount || 0)
    }

    const mostViewedProducts = Object.entries(productViewCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([productId, views]) => {
        const product = productLookup.get(parseInt(productId))
        return product ? {
          name: product.name,
          category: product.category,
          views: views,
        } : null
      })
      .filter(Boolean)

    // Daily stats
    const dailyStats = []
    const interval = (timeFrame === '3m' || timeFrame === '6m') ? 7 : (timeFrame === '1y' ? 14 : 1)
    
    const viewsByDate: Record<string, number> = {}
    for (const v of allProductViews) {
      const d = v.date || ''
      viewsByDate[d] = (viewsByDate[d] || 0) + (v.viewCount || 0)
    }

    for (let i = days - 1; i >= 0; i -= interval) {
      const date = new Date(currentDate)
      date.setDate(date.getDate() - i)
      const dayStart = new Date(date.setHours(0, 0, 0, 0))
      const dayEnd = new Date(date)
      dayEnd.setHours(23, 59, 59, 999)
      const dateStr = dayStart.toISOString().split('T')[0]

      const dayOrders = approvedOrders.filter(o => {
        if (!o.createdAt) return false
        const orderDate = new Date(o.createdAt)
        return orderDate >= dayStart && orderDate <= dayEnd
      })

      dailyStats.push({
        date: dateStr,
        sales: dayOrders.length,
        revenue: dayOrders.reduce((sum, o) => sum + Math.round(parseFloat(String(o.total)) || 0), 0),
        orders: dayOrders.length,
        visitors: viewsByDate[dateStr] || 0,
      })
    }

    // Cart additions
    const filteredCartAdditions = cartAdditions.filter(c => {
      if (!c.date) return false
      return new Date(c.date) >= startDate
    })
    const totalCartAdds = filteredCartAdditions.length

    // Metrics
    const avgOrderValue = totalOrdersCount > 0 ? totalRevenue / totalOrdersCount : 0
    const conversionRate = totalViews > 0 ? (totalOrdersCount / totalViews) * 100 : 0
    const revPerVisitor = totalViews > 0 ? totalRevenue / totalViews : 0

    const resultData = {
      totalRevenue,
      totalOrders: totalOrdersCount,
      pendingOrders: pendingOrdersCount,
      canceledOrders: canceledOrdersCount,
      totalCustomers,
      newCustomers,
      repeatCustomers: repeatCustomersCount,
      totalViews,
      uniqueProductsViewed,
      totalCartAdds,
      avgOrderValue: Math.round(avgOrderValue),
      conversionRate: conversionRate.toFixed(2),
      revPerVisitor: revPerVisitor.toFixed(2),
      topSellingProducts,
      mostViewedProducts,
      topCustomers,
      dailyStats,
      deviceStats: {
        mobile: 0, desktop: 0, tablet: 0,
        ios: 0, android: 0, chrome: 0, safari: 0, other: 0, total: 0
      },
      timeFrame,
      days,
      startDate: startDate.toISOString(),
    }

    // Update global cache
    setCachedDashboard(resultData, timeFrame)

    return NextResponse.json({
      success: true,
      cached: false,
      data: resultData
    })
  } catch (error) {
    console.error('Dashboard analytics error:', error)
    
    // Return stale cache on error
    const cached = getCachedDashboard(timeFrame)
    if (cached) {
      return NextResponse.json({
        success: true,
        cached: true,
        stale: true,
        data: cached.data
      })
    }
    
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch dashboard analytics',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}
