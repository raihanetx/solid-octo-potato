import { NextRequest, NextResponse } from 'next/server'
import { authenticateAdmin, SESSION_COOKIE_NAME, SESSION_DURATION_SECONDS } from '@/lib/auth'

export async function POST(request: NextRequest) {
  try {
    // Get client info for audit logging
    const ip = request.headers.get('x-forwarded-for')?.split(',')[0].trim() 
      || request.headers.get('x-real-ip') 
      || 'unknown'
    const userAgent = request.headers.get('user-agent') || 'unknown'
    
    const { username, password } = await request.json()
    
    if (!username || !password) {
      return NextResponse.json({ 
        success: false, 
        error: 'Username and password required'
      }, { status: 400 })
    }
    
    // Authenticate with rate limiting and audit logging
    const result = await authenticateAdmin(username, password, ip, userAgent)
    
    if (result.success && result.token) {
      // Set secure session cookie with proper settings for persistence
      const response = NextResponse.json({ success: true })
      response.cookies.set(SESSION_COOKIE_NAME, result.token, {
        httpOnly: true,
        secure: false, // Set to false for localhost development
        sameSite: 'lax',
        maxAge: SESSION_DURATION_SECONDS,
        path: '/',
        // Don't set domain for localhost
      })
      console.log('[LOGIN] Session cookie set, duration:', SESSION_DURATION_SECONDS, 'seconds (7 days)')
      return response
    }
    
    // Failed login - return error with remaining attempts
    const statusCode = result.lockedMinutes ? 429 : 401
    
    return NextResponse.json({ 
      success: false, 
      error: result.error || 'Invalid credentials',
      remainingAttempts: result.remainingAttempts || 0,
      lockedMinutes: result.lockedMinutes || 0
    }, { status: statusCode })
  } catch (error) {
    console.error('Login error:', error)
    return NextResponse.json({ 
      success: false, 
      error: 'Something went wrong' 
    }, { status: 500 })
  }
}
