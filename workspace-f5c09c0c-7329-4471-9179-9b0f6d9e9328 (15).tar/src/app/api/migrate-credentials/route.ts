import { NextResponse } from 'next/server'
import { db } from '@/db'
import { settings } from '@/db/schema'
import { sql, eq } from 'drizzle-orm'

export async function GET() {
  try {
    // Add timestamp columns for credentials tracking
    const migrations = [
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS admin_username_updated_at TEXT`,
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS admin_password_updated_at TEXT`,
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS steadfast_api_updated_at TEXT`,
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS cloudinary_updated_at TEXT`,
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS cloudinary_cloud_name TEXT`,
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS cloudinary_api_key TEXT`,
      `ALTER TABLE settings ADD COLUMN IF NOT EXISTS cloudinary_api_secret TEXT`,
    ]

    for (const migration of migrations) {
      try {
        await db.execute(sql.raw(migration))
      } catch (error) {
        console.log('Migration already exists or error:', error)
      }
    }

    // Check if Cloudinary credentials exist in database
    const existing = await db.select().from(settings).where(eq(settings.id, 1)).limit(1)
    
    // If no Cloudinary credentials in DB but we have them from previous setup, seed them
    if (existing.length > 0 && !existing[0].cloudinaryCloudName) {
      // These were the previous .env values - seed them to database
      await db.update(settings)
        .set({
          cloudinaryCloudName: 'dpteezqq9',
          cloudinaryApiKey: '525535772615535',
          cloudinaryApiSecret: 'P1LPKgo1weQpgyQurUdX9aqJCuk',
          cloudinaryUpdatedAt: new Date().toISOString(),
        })
        .where(eq(settings.id, 1))
      
      return NextResponse.json({
        success: true,
        message: 'Credential columns added and Cloudinary credentials seeded to database'
      })
    }

    return NextResponse.json({
      success: true,
      message: 'Credential timestamp columns added successfully'
    })
  } catch (error) {
    console.error('Migration error:', error)
    return NextResponse.json({
      success: false,
      error: 'Migration failed'
    }, { status: 500 })
  }
}
