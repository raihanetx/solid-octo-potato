/**
 * Fix Corrupted Credentials API
 * Clears encrypted credentials that can't be decrypted with the current key
 * This happens when SESSION_SECRET changes or is inconsistent
 */
import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { settings } from '@/db/schema'
import { eq } from 'drizzle-orm'
import { safeDecrypt, isEncrypted } from '@/lib/security'

export async function POST(request: NextRequest) {
  try {
    // Get current settings
    const result = await db.select().from(settings).where(eq(settings.id, 1)).limit(1)
    
    if (result.length === 0) {
      return NextResponse.json({ success: false, error: 'Settings not found' })
    }
    
    const currentSettings = result[0]
    const updates: Record<string, any> = {}
    const issues: string[] = []
    
    // Check each encrypted field
    const encryptedFields = [
      { name: 'cloudinaryApiSecret', value: currentSettings.cloudinaryApiSecret },
      { name: 'steadfastApiKey', value: currentSettings.steadfastApiKey },
      { name: 'steadfastSecretKey', value: currentSettings.steadfastSecretKey },
    ]
    
    for (const field of encryptedFields) {
      if (field.value && isEncrypted(field.value)) {
        const decrypted = safeDecrypt(field.value)
        if (decrypted === null) {
          // Decryption failed - clear this field
          updates[field.name] = ''
          issues.push(`${field.name} - decryption failed, will be cleared`)
        }
      }
    }
    
    if (Object.keys(updates).length > 0) {
      // Clear the corrupted fields
      await db.update(settings)
        .set(updates)
        .where(eq(settings.id, 1))
      
      // Clear cache
      globalThis.__settingsCache = undefined
      globalThis.__courierCredentials = undefined
      
      return NextResponse.json({
        success: true,
        message: `Fixed ${Object.keys(updates).length} corrupted credential(s). Please re-save your credentials in the admin panel.`,
        clearedFields: Object.keys(updates),
        issues
      })
    }
    
    return NextResponse.json({
      success: true,
      message: 'All credentials are valid. No fixes needed.',
      clearedFields: [],
      issues: []
    })
    
  } catch (error) {
    console.error('Fix credentials error:', error)
    return NextResponse.json({
      success: false,
      error: 'Failed to fix credentials'
    })
  }
}

export async function GET(request: NextRequest) {
  try {
    // Check current status without making changes
    const result = await db.select().from(settings).where(eq(settings.id, 1)).limit(1)
    
    if (result.length === 0) {
      return NextResponse.json({ success: false, error: 'Settings not found' })
    }
    
    const currentSettings = result[0]
    const status: Record<string, { encrypted: boolean; canDecrypt: boolean }> = {}
    
    const encryptedFields = [
      { name: 'cloudinaryApiSecret', value: currentSettings.cloudinaryApiSecret },
      { name: 'steadfastApiKey', value: currentSettings.steadfastApiKey },
      { name: 'steadfastSecretKey', value: currentSettings.steadfastSecretKey },
    ]
    
    for (const field of encryptedFields) {
      if (field.value) {
        const encrypted = isEncrypted(field.value)
        const canDecrypt = encrypted ? safeDecrypt(field.value) !== null : true
        status[field.name] = { encrypted, canDecrypt }
      }
    }
    
    return NextResponse.json({
      success: true,
      status,
      sessionSecretSet: !!process.env.SESSION_SECRET,
      encryptionKeySource: process.env.ENCRYPTION_KEY ? 'ENCRYPTION_KEY' : 'SESSION_SECRET'
    })
    
  } catch (error) {
    console.error('Check credentials error:', error)
    return NextResponse.json({
      success: false,
      error: 'Failed to check credentials'
    })
  }
}
