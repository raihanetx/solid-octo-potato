import { NextResponse } from 'next/server'
import { getAuditLogs } from '@/lib/security'

// GET /api/audit-logs - Get recent audit logs
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const limit = parseInt(searchParams.get('limit') || '50')
  
  try {
    const logs = await getAuditLogs(limit)
    
    return NextResponse.json({
      success: true,
      data: logs
    })
  } catch (error) {
    console.error('Error fetching audit logs:', error)
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch audit logs'
    }, { status: 500 })
  }
}
