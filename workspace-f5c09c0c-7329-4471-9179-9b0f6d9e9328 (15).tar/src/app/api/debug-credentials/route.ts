/**
 * Debug API - Check credentials storage
 * Remove this in production!
 */
import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { settings } from '@/db/schema'
import { eq } from 'drizzle-orm'
import { safeDecrypt, isEncrypted } from '@/lib/security'

export async function GET(request: NextRequest) {
  try {
    const result = await db.select().from(settings).where(eq(settings.id, 1)).limit(1)
    
    if (result.length === 0) {
      return NextResponse.json({ error: 'No settings found' })
    }

    const s = result[0]
    
    // Check Cloudinary credentials
    const cloudinaryDebug = {
      cloudName: s.cloudinaryCloudName || 'NOT SET',
      apiKey: s.cloudinaryApiKey || 'NOT SET',
      apiSecret_raw: s.cloudinaryApiSecret ? `${s.cloudinaryApiSecret.substring(0, 50)}...` : 'NOT SET',
      apiSecret_isEncrypted: isEncrypted(s.cloudinaryApiSecret || ''),
      apiSecret_decrypted: s.cloudinaryApiSecret ? safeDecrypt(s.cloudinaryApiSecret) : null,
    }
    
    // Check Steadfast credentials
    const steadfastDebug = {
      apiKey_raw: s.steadfastApiKey ? `${s.steadfastApiKey.substring(0, 50)}...` : 'NOT SET',
      apiKey_isEncrypted: isEncrypted(s.steadfastApiKey || ''),
      apiKey_decrypted: s.steadfastApiKey ? safeDecrypt(s.steadfastApiKey) : null,
      secretKey_raw: s.steadfastSecretKey ? `${s.steadfastSecretKey.substring(0, 50)}...` : 'NOT SET',
      secretKey_isEncrypted: isEncrypted(s.steadfastSecretKey || ''),
      secretKey_decrypted: s.steadfastSecretKey ? safeDecrypt(s.steadfastSecretKey) : null,
    }

    // Check timestamps
    const timestamps = {
      adminUsernameUpdatedAt: s.adminUsernameUpdatedAt || 'NEVER',
      adminPasswordUpdatedAt: s.adminPasswordUpdatedAt || 'NEVER',
      steadfastApiUpdatedAt: s.steadfastApiUpdatedAt || 'NEVER',
      cloudinaryUpdatedAt: s.cloudinaryUpdatedAt || 'NEVER',
    }

    return NextResponse.json({
      cloudinary: cloudinaryDebug,
      steadfast: steadfastDebug,
      timestamps,
      sessionSecretSet: !!process.env.SESSION_SECRET,
      encryptionKeySet: !!process.env.ENCRYPTION_KEY,
    })
  } catch (error) {
    console.error('Debug error:', error)
    return NextResponse.json({ error: String(error) }, { status: 500 })
  }
}
