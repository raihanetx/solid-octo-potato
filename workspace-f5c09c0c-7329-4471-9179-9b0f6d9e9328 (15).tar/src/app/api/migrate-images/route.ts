import { NextRequest, NextResponse } from 'next/server'
import { v2 as cloudinary } from 'cloudinary'
import { db } from '@/db'
import { settings, products, categories } from '@/db/schema'
import { eq } from 'drizzle-orm'

// Get Cloudinary config from database (with env fallback)
async function getCloudinaryConfig() {
  // First check environment variables (fastest)
  const envConfig = {
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET,
  }
  
  // If all env vars are set, use them
  if (envConfig.cloud_name && envConfig.api_key && envConfig.api_secret) {
    return envConfig
  }
  
  // Otherwise, fetch from database
  try {
    const result = await db.select().from(settings).where(eq(settings.id, 1)).limit(1)
    if (result.length > 0) {
      const s = result[0]
      return {
        cloud_name: s.cloudinaryCloudName || envConfig.cloud_name,
        api_key: s.cloudinaryApiKey || envConfig.api_key,
        api_secret: s.cloudinaryApiSecret || envConfig.api_secret,
      }
    }
  } catch (error) {
    console.error('Failed to fetch Cloudinary config from database:', error)
  }
  
  return envConfig
}

// Upload base64 image to Cloudinary
async function uploadBase64ToCloudinary(
  base64Data: string, 
  folder: string,
  config: { cloud_name: string; api_key: string; api_secret: string }
): Promise<string | null> {
  try {
    // Check if it's already a URL (not base64)
    if (base64Data.startsWith('http://') || base64Data.startsWith('https://')) {
      return base64Data
    }
    
    // Check if it's base64
    if (!base64Data.startsWith('data:image')) {
      return base64Data // Not an image, return as-is
    }
    
    console.log(`Uploading to Cloudinary folder: ${folder}`)
    
    // Configure Cloudinary
    cloudinary.config({
      cloud_name: config.cloud_name,
      api_key: config.api_key,
      api_secret: config.api_secret,
    })
    
    const result = await cloudinary.uploader.upload(base64Data, {
      folder: `krishi-bitan/${folder}`,
      resource_type: 'image',
      transformation: [
        { quality: 'auto:good' },
        { fetch_format: 'auto' },
      ],
    })
    
    console.log(`Uploaded successfully: ${result.secure_url}`)
    return result.secure_url
  } catch (error) {
    console.error('Failed to upload to Cloudinary:', error)
    return null
  }
}

// POST /api/migrate-images - Migrate all base64 images to Cloudinary
export async function POST(request: NextRequest) {
  const results = {
    settings: { logo: false, favicon: false, heroImages: 0 },
    products: 0,
    categories: 0,
    errors: [] as string[]
  }
  
  try {
    // Get Cloudinary config
    const config = await getCloudinaryConfig()
    
    if (!config.cloud_name || !config.api_key || !config.api_secret) {
      return NextResponse.json({
        success: false,
        error: 'Cloudinary is not configured. Please add Cloudinary credentials in Settings > Credentials.',
        needsConfig: true
      }, { status: 400 })
    }
    
    // 1. Migrate Settings (logo, favicon, hero images)
    const settingsData = await db.select().from(settings).where(eq(settings.id, 1)).limit(1)
    
    if (settingsData.length > 0) {
      const s = settingsData[0]
      
      // Migrate logo
      if (s.logoUrl && s.logoUrl.startsWith('data:image')) {
        const newUrl = await uploadBase64ToCloudinary(s.logoUrl, 'logo', config)
        if (newUrl) {
          await db.update(settings).set({ logoUrl: newUrl }).where(eq(settings.id, 1))
          results.settings.logo = true
        }
      }
      
      // Migrate favicon
      if (s.faviconUrl && s.faviconUrl.startsWith('data:image')) {
        const newUrl = await uploadBase64ToCloudinary(s.faviconUrl, 'favicon', config)
        if (newUrl) {
          await db.update(settings).set({ faviconUrl: newUrl }).where(eq(settings.id, 1))
          results.settings.favicon = true
        }
      }
      
      // Migrate hero images
      if (s.heroImages) {
        try {
          const heroArray = JSON.parse(s.heroImages as string)
          if (Array.isArray(heroArray)) {
            const newHeroImages: string[] = []
            for (const img of heroArray) {
              if (img.startsWith('data:image')) {
                const newUrl = await uploadBase64ToCloudinary(img, 'hero', config)
                if (newUrl) {
                  newHeroImages.push(newUrl)
                  results.settings.heroImages++
                } else {
                  newHeroImages.push(img) // Keep original if upload failed
                }
              } else {
                newHeroImages.push(img) // Already a URL
              }
            }
            await db.update(settings).set({ heroImages: JSON.stringify(newHeroImages) }).where(eq(settings.id, 1))
          }
        } catch (e) {
          results.errors.push('Failed to parse hero images')
        }
      }
    }
    
    // 2. Migrate Products images
    const productsData = await db.select().from(products)
    for (const product of productsData) {
      if (product.image && product.image.startsWith('data:image')) {
        const newUrl = await uploadBase64ToCloudinary(product.image, 'products', config)
        if (newUrl) {
          await db.update(products).set({ image: newUrl }).where(eq(products.id, product.id))
          results.products++
        }
      }
    }
    
    // 3. Migrate Categories images
    const categoriesData = await db.select().from(categories)
    for (const category of categoriesData) {
      if (category.image && category.image.startsWith('data:image')) {
        const newUrl = await uploadBase64ToCloudinary(category.image, 'categories', config)
        if (newUrl) {
          await db.update(categories).set({ image: newUrl }).where(eq(categories.id, category.id))
          results.categories++
        }
      }
    }
    
    // Clear caches
    globalThis.__settingsCache = undefined
    globalThis.__shopDataCache = undefined
    
    return NextResponse.json({
      success: true,
      message: 'Image migration completed',
      results
    })
  } catch (error) {
    console.error('Migration error:', error)
    return NextResponse.json({
      success: false,
      error: 'Migration failed',
      results
    }, { status: 500 })
  }
}

// GET /api/migrate-images - Check how many base64 images exist
export async function GET() {
  const stats = {
    settings: { logo: false, favicon: false, heroImages: 0 },
    products: 0,
    categories: 0,
    total: 0
  }
  
  try {
    // Check settings
    const settingsData = await db.select().from(settings).where(eq(settings.id, 1)).limit(1)
    if (settingsData.length > 0) {
      const s = settingsData[0]
      if (s.logoUrl?.startsWith('data:image')) {
        stats.settings.logo = true
        stats.total++
      }
      if (s.faviconUrl?.startsWith('data:image')) {
        stats.settings.favicon = true
        stats.total++
      }
      if (s.heroImages) {
        try {
          const heroArray = JSON.parse(s.heroImages as string)
          const base64Count = heroArray.filter((img: string) => img.startsWith('data:image')).length
          stats.settings.heroImages = base64Count
          stats.total += base64Count
        } catch { /* empty */ }
      }
    }
    
    // Check products
    const productsData = await db.select().from(products)
    stats.products = productsData.filter(p => p.image?.startsWith('data:image')).length
    stats.total += stats.products
    
    // Check categories
    const categoriesData = await db.select().from(categories)
    stats.categories = categoriesData.filter(c => c.image?.startsWith('data:image')).length
    stats.total += stats.categories
    
    return NextResponse.json({
      success: true,
      stats,
      hasBase64Images: stats.total > 0
    })
  } catch (error) {
    console.error('Check error:', error)
    return NextResponse.json({
      success: false,
      error: 'Failed to check images'
    }, { status: 500 })
  }
}
