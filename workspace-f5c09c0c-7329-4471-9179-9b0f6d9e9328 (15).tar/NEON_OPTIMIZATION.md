# Neon Database & Cloudinary Optimization Guide

## 🔴 CRITICAL: Connection URL

### ALWAYS use the POOLED connection URL for production!

**Pooled URL (FAST - keeps connections warm):**
```
postgresql://neondb_owner:npg_fpYOD6th3nBT@ep-misty-mouse-a17jt54s-pooler.ap-southeast-1.aws.neon.tech/neondb?sslmode=require
```

**Direct URL (SLOW - 45-60s cold starts):**
```
❌ ep-misty-mouse-a17jt54s.ap-southeast-1.aws.neon.tech (NO -pooler suffix)
```

### How to identify pooled URL:
- Has `-pooler` in the hostname
- Example: `ep-xxx-pooler.region.aws.neon.tech`

---

## 🟢 Cloudinary Configuration

### Credentials (Production)
```
CLOUDINARY_CLOUD_NAME=dpteezqq9
CLOUDINARY_API_KEY=525535772615535
CLOUDINARY_API_SECRET=P1LPKgo1weQpgyQurUdX9aqJCuk
```

### Folder Structure
- `krishi-bitan/logo/` - Logo images
- `krishi-bitan/favicon/` - Favicon images
- `krishi-bitan/hero/` - Hero slider images
- `krishi-bitan/products/` - Product images
- `krishi-bitan/categories/` - Category images

### Upload API
POST `/api/upload` with formData: `{ file: File, type: 'logo'|'favicon'|'hero'|'product'|'category' }`

---

## 🚀 Optimization Strategy

### 1. NO Base64 Images in Database
- ❌ NEVER store base64 images in database (causes 7MB+ responses)
- ✅ ALWAYS upload to Cloudinary first, store URL only
- ✅ Use `/api/migrate-images` to migrate existing base64 images

### 2. Global Caching (in `/src/db/index.ts`)
- Uses `globalThis` to persist cache across hot reloads
- Settings: 60s TTL
- Shop Data: 60s TTL  
- Dashboard: 30s TTL

### 3. Parallel Queries
- ALL API endpoints use `Promise.all()` for parallel queries
- NO sequential database calls
- NO N+1 queries - use lookup maps instead

### 4. Memory Cache for Zustand Store
- Uses in-memory cache instead of localStorage
- localStorage has 5-10MB limit, causes QuotaExceededError
- Memory cache has no size limit

---

## 📊 Expected Performance

| Request Type | Before | After |
|--------------|--------|-------|
| Settings API | 7MB+ response | **~2KB** |
| Shop Data API | 7MB+ response | **~2KB** |
| First API call | 45-60s | **~5s** |
| Cached API call | N/A | **<50ms** |

---

## ⚠️ NEVER DO THESE

1. ❌ NEVER use SQLite for production - it's local only
2. ❌ NEVER use direct Neon URL (without -pooler)
3. ❌ NEVER store base64 images in database
4. ❌ NEVER store large data in localStorage
5. ❌ NEVER make sequential database calls
6. ❌ NEVER make N+1 queries (fetch per item in loop)
7. ❌ NEVER forget to add caching for read-heavy endpoints

---

## 📁 Key Files

- `/src/db/index.ts` - Database connection + caching
- `/src/app/api/upload/route.ts` - Cloudinary upload
- `/src/app/api/migrate-images/route.ts` - Migrate base64 to Cloudinary
- `/src/app/api/settings/route.ts` - Settings with cache
- `/src/app/api/shop-data/route.ts` - Shop data with cache
- `/src/store/useShopStore.ts` - Memory cache (not localStorage)
- `/src/components/ui/ImageWithSkeleton.tsx` - Image with skeleton loading

---

## 🔧 Useful Commands

```bash
# Check for base64 images
curl http://localhost:3000/api/migrate-images

# Migrate base64 to Cloudinary
curl -X POST http://localhost:3000/api/migrate-images
```

---

## Last Updated: 2025-01-13

This file serves as a reminder for future conversations. DO NOT DELETE.
